/*
 * Equifax Ecuador C.A. Sistema: Fast Decision Creado: 4 sep. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.models;

import java.io.Serializable;

import javax.persistence.Column;

import com.equifax.login.notaciones.SecuenciaAutomatica;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class FDECModeloPK implements Serializable {
    private static final long serialVersionUID = 1L;
    @Column(name = "IdModeloProyecto")
    @SecuenciaAutomatica
    private Long idModeloProyecto;

    /**
     * Crea una nueva instancia de la clase CargaPK
     */
    public FDECModeloPK() {
    }

    /**
     * Crea una nueva instancia de la clase FEDCModeloPK
     * @param idModeloProyecto
     */
    public FDECModeloPK(Long idModeloProyecto) {
        super();
        this.idModeloProyecto = idModeloProyecto;
    }

    /**
     * Obtiene el atributo de clase: "idModeloProyecto"
     * @return el/la idModeloProyecto
     */
    public Long getIdModeloProyecto() {
        return this.idModeloProyecto;
    }

    /**
     * Asigna valor al atributo de clase: "idModeloProyecto"
     * @param idModeloProyecto el/la idModeloProyecto para asignar el valor
     */
    public void setIdModeloProyecto(Long idModeloProyecto) {
        this.idModeloProyecto = idModeloProyecto;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof FDECModeloPK)) {
            return false;
        }
        FDECModeloPK castOther = (FDECModeloPK) other;
        return (this.idModeloProyecto == castOther.idModeloProyecto);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int hash = 17;
        if (this.idModeloProyecto != null) {
            hash = hash * prime + ((int) (this.idModeloProyecto ^ (this.idModeloProyecto >>> 32)));
        }
        return hash;
    }
}
