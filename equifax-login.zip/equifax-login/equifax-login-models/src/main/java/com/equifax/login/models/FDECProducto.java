/*
 * Equifax Ecuador C.A. Sistema: Fast Decision Creado: 4 sep. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author yxh24
 * @version $Revision: $
 */
@Entity
// @Audited(withModifiedFlag = true)
@Table(name = "FDEC_Producto")
public class FDECProducto implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    private FDECProductoPK id;
    @Column(name = "IdProducto")
    private Long idProducto;
    @Column(name = "Canal")
    private String canal;
    @Column(name = "Abreviatura")
    private String abreviatura;
    @Column(name = "idProductoMK")
    private Long idProductoMK;
    @Column(name = "IdCategoria")
    private Long idCategoria;
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdReporteProyecto", referencedColumnName = "IdReporteProyecto")
    private FDECReporte fdecReporte;

    /**
     * Crea una nueva instancia de la clase FEDCProducto
     */
    public FDECProducto() {
        super();
    }

    /**
     * Crea una nueva instancia de la clase FEDCProducto
     * @param id
     */
    public FDECProducto(FDECProductoPK id) {
        super();
        this.id = id;
    }

    /**
     * Obtiene el atributo de clase: "id"
     * @return el/la id
     */
    public FDECProductoPK getId() {
        return this.id;
    }

    /**
     * Asigna valor al atributo de clase: "id"
     * @param id el/la id para asignar el valor
     */
    public void setId(FDECProductoPK id) {
        this.id = id;
    }

    /**
     * Obtiene el atributo de clase: "idProducto"
     * @return el/la idProducto
     */
    public Long getIdProducto() {
        return this.idProducto;
    }

    /**
     * Asigna valor al atributo de clase: "idProducto"
     * @param idProducto el/la idProducto para asignar el valor
     */
    public void setIdProducto(Long idProducto) {
        this.idProducto = idProducto;
    }

    /**
     * Obtiene el atributo de clase: "canal"
     * @return el/la canal
     */
    public String getCanal() {
        return this.canal;
    }

    /**
     * Asigna valor al atributo de clase: "canal"
     * @param canal el/la canal para asignar el valor
     */
    public void setCanal(String canal) {
        this.canal = canal;
    }

    /**
     * Obtiene el atributo de clase: "abreviatura"
     * @return el/la abreviatura
     */
    public String getAbreviatura() {
        return this.abreviatura;
    }

    /**
     * Asigna valor al atributo de clase: "abreviatura"
     * @param abreviatura el/la abreviatura para asignar el valor
     */
    public void setAbreviatura(String abreviatura) {
        this.abreviatura = abreviatura;
    }

    /**
     * Obtiene el atributo de clase: "idProductoMK"
     * @return el/la idProductoMK
     */
    public Long getIdProductoMK() {
        return this.idProductoMK;
    }

    /**
     * Asigna valor al atributo de clase: "idProductoMK"
     * @param idProductoMK el/la idProductoMK para asignar el valor
     */
    public void setIdProductoMK(Long idProductoMK) {
        this.idProductoMK = idProductoMK;
    }

    /**
     * Obtiene el atributo de clase: "idCategoria"
     * @return el/la idCategoria
     */
    public Long getIdCategoria() {
        return this.idCategoria;
    }

    /**
     * Asigna valor al atributo de clase: "idCategoria"
     * @param idCategoria el/la idCategoria para asignar el valor
     */
    public void setIdCategoria(Long idCategoria) {
        this.idCategoria = idCategoria;
    }

    /**
     * Obtiene el atributo de clase: "fdecReporte"
     * @return el/la fdecReporte
     */
    public FDECReporte getFdecReporte() {
        return this.fdecReporte;
    }

    /**
     * Asigna valor al atributo de clase: "fdecReporte"
     * @param fdecReporte el/la fdecReporte para asignar el valor
     */
    public void setFdecReporte(FDECReporte fdecReporte) {
        this.fdecReporte = fdecReporte;
    }
}
