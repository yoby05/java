/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Digits;

/**
 * @author yxh24
 */
// @Entity
@NamedQueries({
        @NamedQuery(name = RFRInstitucion.OBTENER_INSTITUCION_POR_IDENTIFICADOR,
                query = "SELECT i FROM RFRInstitucion i where i.id.codigoInstitucion =:codigoInstitucion"),
        @NamedQuery(name = RFRInstitucion.OBTENER_INSTITUCION_POR_IDENTIFICADORES,
                query = "SELECT i FROM RFRInstitucion i where i.id.codigoInstitucion IN (:codigos)"),
        @NamedQuery(name = RFRInstitucion.OBTENER_INSTITUCION_POR_NOMBRE_TIPO,
                query = "SELECT i FROM RFRInstitucion i where i.nombreTipoInstitucion =:nombreTipoInstitucion") })
@Table(name = "RFR_INSTITUCION")
public class RFRInstitucion implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * Query para obtener Institucion por identificador
     */
    public static final String OBTENER_INSTITUCION_POR_IDENTIFICADOR = "RFRInstitucion.ObtenerInstitucionPorIdentificador";
    /**
     * Query para obtener Instituciones por identificadores
     */
    public static final String OBTENER_INSTITUCION_POR_IDENTIFICADORES = "RFRInstitucion.ObtenerInstitucionPorIdentificadores";
    /**
     * /** Query para obtener Instituciones por nombre
     */
    public static final String OBTENER_INSTITUCION_POR_NOMBRE_TIPO = "RFRInstitucion.ObtenerInstitucionPorNombreTipo";
    @EmbeddedId
    private RFRInstitucionPK id;
    @Column(name = "NOM_INSTITUCION")
    private String nombreInstitucion;
    @Column(name = "COD_TIPO_INSTITUCION")
    private Long codigoTipoInstitucion;
    @Column(name = "NOM_TIPO_INSTITUCION")
    private String nombreTipoInstitucion;
    @Column(name = "NOM_DISPLAY")
    private String nombreDisplay;
    @Column(name = "CONTACTO")
    private String contacto;
    @Column(name = "TELEFONO_CONTACTO")
    private String telefonoContacto;
    @Column(name = "CIUDAD")
    private String ciudad;
    @Column(name = "PROVINCIA")
    private String provincia;
    @Column(name = "COD_SEGMENTO")
    private String codigoSegmento;
    @Column(name = "COD_CLIENTE")
    private Long codigoCliente;
    @Digits(integer = 13, fraction = 0)
    @Column(name = "RUC")
    private String ruc;
    @Column(name = "REGION")
    private String region;
    @Temporal(TemporalType.DATE)
    @Column(name = "FEC_EXPRESA_TITULAR")
    private Date fechaExpresaTitular;
    @Temporal(TemporalType.DATE)
    @Column(name = "FEC_EXPRESA_GARANTE")
    private Date fechaExpresaGarante;
    @Column(name = "CANT_MIN_REGISTROS")
    private Long cantidadMinRegistros;
    @Column(name = "PORC_REG_NEGATIVOS")
    private Long porcentajeRegNegativos;

    /**
     * Crea una nueva instancia de la clase RFRInstitucion
     */
    public RFRInstitucion() {
        super();
    }

    /**
     * Crea una nueva instancia de la clase RFRInstitucion
     * @param id
     */
    public RFRInstitucion(RFRInstitucionPK id) {
        super();
        this.id = id;
    }

    /**
     * Obtiene el atributo de clase: "id"
     * @return el/la id
     */
    public RFRInstitucionPK getId() {
        return this.id;
    }

    /**
     * Asigna valor al atributo de clase: "id"
     * @param id el/la id para asignar el valor
     */
    public void setId(RFRInstitucionPK id) {
        this.id = id;
    }

    /**
     * Obtiene el atributo de clase: "nombreInstitucion"
     * @return el/la nombreInstitucion
     */
    public String getNombreInstitucion() {
        return this.nombreInstitucion;
    }

    /**
     * Asigna valor al atributo de clase: "nombreInstitucion"
     * @param nombreInstitucion el/la nombreInstitucion para asignar el valor
     */
    public void setNombreInstitucion(String nombreInstitucion) {
        this.nombreInstitucion = nombreInstitucion;
    }

    /**
     * Obtiene el atributo de clase: "codigoTipoInstitucion"
     * @return el/la codigoTipoInstitucion
     */
    public Long getCodigoTipoInstitucion() {
        return this.codigoTipoInstitucion;
    }

    /**
     * Asigna valor al atributo de clase: "codigoTipoInstitucion"
     * @param codigoTipoInstitucion el/la codigoTipoInstitucion para asignar el valor
     */
    public void setCodigoTipoInstitucion(Long codigoTipoInstitucion) {
        this.codigoTipoInstitucion = codigoTipoInstitucion;
    }

    /**
     * Obtiene el atributo de clase: "nombreTipoInstitucion"
     * @return el/la nombreTipoInstitucion
     */
    public String getNombreTipoInstitucion() {
        return this.nombreTipoInstitucion;
    }

    /**
     * Asigna valor al atributo de clase: "nombreTipoInstitucion"
     * @param nombreTipoInstitucion el/la nombreTipoIntitucion para asignar el valor
     */
    public void setNombreTipoInstitucion(String nombreTipoInstitucion) {
        this.nombreTipoInstitucion = nombreTipoInstitucion;
    }

    /**
     * Obtiene el atributo de clase: "nombreDisplay"
     * @return el/la nombreDisplay
     */
    public String getNombreDisplay() {
        return this.nombreDisplay;
    }

    /**
     * Asigna valor al atributo de clase: "nombreDisplay"
     * @param nombreDisplay el/la nombreDisplay para asignar el valor
     */
    public void setNombreDisplay(String nombreDisplay) {
        this.nombreDisplay = nombreDisplay;
    }

    /**
     * Obtiene el atributo de clase: "contacto"
     * @return el/la contacto
     */
    public String getContacto() {
        return this.contacto;
    }

    /**
     * Asigna valor al atributo de clase: "contacto"
     * @param contacto el/la contacto para asignar el valor
     */
    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    /**
     * Obtiene el atributo de clase: "telefonoContacto"
     * @return el/la telefonoContacto
     */
    public String getTelefonoContacto() {
        return this.telefonoContacto;
    }

    /**
     * Asigna valor al atributo de clase: "telefonoContacto"
     * @param telefonoContacto el/la telefonoContacto para asignar el valor
     */
    public void setTelefonoContacto(String telefonoContacto) {
        this.telefonoContacto = telefonoContacto;
    }

    /**
     * Obtiene el atributo de clase: "ciudad"
     * @return el/la ciudad
     */
    public String getCiudad() {
        return this.ciudad;
    }

    /**
     * Asigna valor al atributo de clase: "ciudad"
     * @param ciudad el/la ciudad para asignar el valor
     */
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    /**
     * Obtiene el atributo de clase: "provincia"
     * @return el/la provincia
     */
    public String getProvincia() {
        return this.provincia;
    }

    /**
     * Asigna valor al atributo de clase: "provincia"
     * @param provincia el/la provincia para asignar el valor
     */
    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    /**
     * Obtiene el atributo de clase: "codigoSegmento"
     * @return el/la codigoSegmento
     */
    public String getCodigoSegmento() {
        return this.codigoSegmento;
    }

    /**
     * Asigna valor al atributo de clase: "codigoSegmento"
     * @param codigoSegmento el/la codigoSegmento para asignar el valor
     */
    public void setCodigoSegmento(String codigoSegmento) {
        this.codigoSegmento = codigoSegmento;
    }

    /**
     * Obtiene el atributo de clase: "codigoCliente"
     * @return el/la codigoCliente
     */
    public Long getCodigoCliente() {
        return this.codigoCliente;
    }

    /**
     * Asigna valor al atributo de clase: "codigoCliente"
     * @param codigoCliente el/la codigoCliente para asignar el valor
     */
    public void setCodigoCliente(Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    /**
     * Obtiene el atributo de clase: "ruc"
     * @return el/la ruc
     */
    public String getRuc() {
        return this.ruc;
    }

    /**
     * Asigna valor al atributo de clase: "ruc"
     * @param ruc el/la ruc para asignar el valor
     */
    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    /**
     * Obtiene el atributo de clase: "region"
     * @return el/la region
     */
    public String getRegion() {
        return this.region;
    }

    /**
     * Asigna valor al atributo de clase: "region"
     * @param region el/la region para asignar el valor
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * Obtiene el atributo de clase: "fechaExpresaTitular"
     * @return el/la fechaExpresaTitular
     */
    public Date getFechaExpresaTitular() {
        return this.fechaExpresaTitular;
    }

    /**
     * Asigna valor al atributo de clase: "fechaExpresaTitular"
     * @param fechaExpresaTitular el/la fechaExpresaTitular para asignar el valor
     */
    public void setFechaExpresaTitular(Date fechaExpresaTitular) {
        this.fechaExpresaTitular = fechaExpresaTitular;
    }

    /**
     * Obtiene el atributo de clase: "fechaExpresaGarante"
     * @return el/la fechaExpresaGarante
     */
    public Date getFechaExpresaGarante() {
        return this.fechaExpresaGarante;
    }

    /**
     * Asigna valor al atributo de clase: "fechaExpresaGarante"
     * @param fechaExpresaGarante el/la fechaExpresaGarante para asignar el valor
     */
    public void setFechaExpresaGarante(Date fechaExpresaGarante) {
        this.fechaExpresaGarante = fechaExpresaGarante;
    }

    /**
     * Obtiene el atributo de clase: "cantidadMinRegistros"
     * @return el/la cantidadMinRegistros
     */
    public Long getCantidadMinRegistros() {
        return this.cantidadMinRegistros;
    }

    /**
     * Asigna valor al atributo de clase: "cantidadMinRegistros"
     * @param cantidadMinRegistros el/la cantidadMinRegistros para asignar el valor
     */
    public void setCantidadMinRegistros(Long cantidadMinRegistros) {
        this.cantidadMinRegistros = cantidadMinRegistros;
    }

    /**
     * Obtiene el atributo de clase: "porcentajeRegNegativos"
     * @return el/la porcentajeRegNegativos
     */
    public Long getPorcentajeRegNegativos() {
        return this.porcentajeRegNegativos;
    }

    /**
     * Asigna valor al atributo de clase: "porcentajeRegNegativos"
     * @param porcentajeRegNegativos el/la porcentajeRegNegativos para asignar el valor
     */
    public void setPorcentajeRegNegativos(Long porcentajeRegNegativos) {
        this.porcentajeRegNegativos = porcentajeRegNegativos;
    }
}
