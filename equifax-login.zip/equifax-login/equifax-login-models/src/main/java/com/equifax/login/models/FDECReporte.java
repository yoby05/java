/*
 * Equifax Ecuador C.A. Sistema: Fast Decision Creado: 4 sep. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.models;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author yxh24
 * @version $Revision: $
 */
@Entity
// @Audited(withModifiedFlag = true)
@Table(name = "FDEC_Reporte")
public class FDECReporte implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    private FDECReportePK id;
    @Column(name = "IdReporte")
    private Long idReporte;
    @Column(name = "Nombre")
    private String nombre;
    @Column(name = "IdCliente")
    private Long idCliente;
    @Column(name = "Valida")
    private String valida;
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdProyecto", referencedColumnName = "IdProyecto")
    private FDECProyecto fdecProyecto;
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST, mappedBy = "fdecReporte")
    private FDECProducto fdecProducto;
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "modeloReporte")
    private List<FDECModelo> tiposModelos;

    /**
     * Crea una nueva instancia de la clase FDECReporte
     */
    public FDECReporte() {
        super();
    }

    /**
     * Crea una nueva instancia de la clase FDECReporte
     * @param id
     */
    public FDECReporte(FDECReportePK id) {
        super();
        this.id = id;
    }

    /**
     * Obtiene el atributo de clase: "id"
     * @return el/la id
     */
    public FDECReportePK getId() {
        return this.id;
    }

    /**
     * Asigna valor al atributo de clase: "id"
     * @param id el/la id para asignar el valor
     */
    public void setId(FDECReportePK id) {
        this.id = id;
    }

    /**
     * Obtiene el atributo de clase: "idReporte"
     * @return el/la idReporte
     */
    public Long getIdReporte() {
        return this.idReporte;
    }

    /**
     * Asigna valor al atributo de clase: "idReporte"
     * @param idReporte el/la idReporte para asignar el valor
     */
    public void setIdReporte(Long idReporte) {
        this.idReporte = idReporte;
    }

    /**
     * Obtiene el atributo de clase: "nombre"
     * @return el/la nombre
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Asigna valor al atributo de clase: "nombre"
     * @param nombre el/la nombre para asignar el valor
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el atributo de clase: "idCliente"
     * @return el/la idCliente
     */
    public Long getIdCliente() {
        return this.idCliente;
    }

    /**
     * Asigna valor al atributo de clase: "idCliente"
     * @param idCliente el/la idCliente para asignar el valor
     */
    public void setIdCliente(Long idCliente) {
        this.idCliente = idCliente;
    }

    /**
     * Obtiene el atributo de clase: "valida"
     * @return el/la valida
     */
    public String getValida() {
        return this.valida;
    }

    /**
     * Asigna valor al atributo de clase: "valida"
     * @param valida el/la valida para asignar el valor
     */
    public void setValida(String valida) {
        this.valida = valida;
    }

    /**
     * Obtiene el atributo de clase: "fdecProyecto"
     * @return el/la fdecProyecto
     */
    public FDECProyecto getFdecProyecto() {
        return this.fdecProyecto;
    }

    /**
     * Asigna valor al atributo de clase: "fdecProyecto"
     * @param fdecProyecto el/la fdecProyecto para asignar el valor
     */
    public void setFdecProyecto(FDECProyecto fdecProyecto) {
        this.fdecProyecto = fdecProyecto;
    }

    /**
     * Obtiene el atributo de clase: "fdecProducto"
     * @return el/la fdecProducto
     */
    public FDECProducto getFdecProducto() {
        return this.fdecProducto;
    }

    /**
     * Asigna valor al atributo de clase: "fdecProducto"
     * @param fdecProducto el/la fdecProducto para asignar el valor
     */
    public void setFdecProducto(FDECProducto fdecProducto) {
        this.fdecProducto = fdecProducto;
    }

    /**
     * Obtiene el atributo de clase: "tiposModelos"
     * @return el/la tiposModelos
     */
    public List<FDECModelo> getTiposModelos() {
        return this.tiposModelos;
    }

    /**
     * Asigna valor al atributo de clase: "tiposModelos"
     * @param tiposModelos el/la tiposModelos para asignar el valor
     */
    public void setTiposModelos(List<FDECModelo> tiposModelos) {
        this.tiposModelos = tiposModelos;
    }
}
