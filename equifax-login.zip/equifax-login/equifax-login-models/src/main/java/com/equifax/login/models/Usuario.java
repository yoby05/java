/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 4 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.models;

import java.security.Principal;
import java.util.List;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class Usuario implements Principal {
    private String nombreUsuario;
    private String passUsuario;
    private List<String> roles;

    /**
     * Crea una nueva instancia de la clase Usuario
     */
    public Usuario() {
    }

    /**
     * Crea una nueva instancia de la clase Usuario
     * @param nombreUsuario
     */
    public Usuario(String nombreUsuario) {
        super();
        this.nombreUsuario = nombreUsuario;
    }

    /**
     * Obtiene el atributo de clase: "nombreUsuario"
     * @return el/la nombreUsuario
     */
    public String getNombreUsuario() {
        return this.nombreUsuario;
    }

    /**
     * Asigna valor al atributo de clase: "nombreUsuario"
     * @param nombreUsuario el/la nombreUsuario para asignar el valor
     */
    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    /**
     * Obtiene el atributo de clase: "passUsuario"
     * @return el/la passUsuario
     */
    public String getPassUsuario() {
        return this.passUsuario;
    }

    /**
     * Asigna valor al atributo de clase: "passUsuario"
     * @param passUsuario el/la passUsuario para asignar el valor
     */
    public void setPassUsuario(String passUsuario) {
        this.passUsuario = passUsuario;
    }

    /**
     * Obtiene el atributo de clase: "roles"
     * @return el/la roles
     */
    public List<String> getRoles() {
        return this.roles;
    }

    /**
     * Asigna valor al atributo de clase: "roles"
     * @param roles el/la roles para asignar el valor
     */
    public void setRoles(List<String> roles) {
        this.roles = roles;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getName() {
        return this.nombreUsuario;
    }
}
