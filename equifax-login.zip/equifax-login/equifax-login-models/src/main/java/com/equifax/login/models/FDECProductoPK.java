/*
 * Equifax Ecuador C.A. Sistema: Fast Decision Creado: 4 sep. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.models;

import java.io.Serializable;

import javax.persistence.Column;

import com.equifax.login.notaciones.SecuenciaAutomatica;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class FDECProductoPK implements Serializable {
    private static final long serialVersionUID = 1L;
    @Column(name = "IdProductoProyecto")
    @SecuenciaAutomatica
    private Long idProductoProyecto;

    /**
     * Crea una nueva instancia de la clase CargaPK
     */
    public FDECProductoPK() {
    }

    /**
     * Crea una nueva instancia de la clase FEDCProductoPK
     * @param idProductoProyecto
     */
    public FDECProductoPK(Long idProductoProyecto) {
        super();
        this.idProductoProyecto = idProductoProyecto;
    }

    /**
     * Obtiene el atributo de clase: "idProductoProyecto"
     * @return el/la idProductoProyecto
     */
    public Long getIdProductoProyecto() {
        return this.idProductoProyecto;
    }

    /**
     * Asigna valor al atributo de clase: "idProductoProyecto"
     * @param idProductoProyecto el/la idProductoProyecto para asignar el valor
     */
    public void setIdProductoProyecto(Long idProductoProyecto) {
        this.idProductoProyecto = idProductoProyecto;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof FDECProductoPK)) {
            return false;
        }
        FDECProductoPK castOther = (FDECProductoPK) other;
        return (this.idProductoProyecto == castOther.idProductoProyecto);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int hash = 17;
        if (this.idProductoProyecto != null) {
            hash = hash * prime + ((int) (this.idProductoProyecto ^ (this.idProductoProyecto >>> 32)));
        }
        return hash;
    }
}
