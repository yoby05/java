/*
 * Equifax Ecuador C.A. Sistema: Fast Decision Creado: 4 sep. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

/**
 * @author yxh24
 * @version $Revision: $
 */
@Entity
@Audited // (withModifiedFlag = true)
@Table(name = "FDEC_Proyecto")
public class FDECProyecto implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    private FDECProyectoPK id;
    @Column(name = "Estado")
    private String estadoProyecto;
    // @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST, mappedBy = "fdecProyecto")
    // private FDECReporte fdecReporte;

    /**
     * Crea una nueva instancia de la clase FEDCProyecto
     */
    public FDECProyecto() {
        super();
    }

    /**
     * Crea una nueva instancia de la clase FEDCProyecto
     * @param id
     */
    public FDECProyecto(FDECProyectoPK id) {
        super();
        this.id = id;
    }

    /**
     * Obtiene el atributo de clase: "id"
     * @return el/la id
     */
    public FDECProyectoPK getId() {
        return this.id;
    }

    /**
     * Asigna valor al atributo de clase: "id"
     * @param id el/la id para asignar el valor
     */
    public void setId(FDECProyectoPK id) {
        this.id = id;
    }

    /**
     * Obtiene el atributo de clase: "estadoProyecto"
     * @return el/la estadoProyecto
     */
    public String getEstadoProyecto() {
        return this.estadoProyecto;
    }

    /**
     * Asigna valor al atributo de clase: "estadoProyecto"
     * @param estadoProyecto el/la estadoProyecto para asignar el valor
     */
    public void setEstadoProyecto(String estadoProyecto) {
        this.estadoProyecto = estadoProyecto;
    }
    // /**
    // * Obtiene el atributo de clase: "fdecReporte"
    // * @return el/la fdecReporte
    // */
    // public FDECReporte getFdecReporte() {
    // return this.fdecReporte;
    // }
    //
    // /**
    // * Asigna valor al atributo de clase: "fdecReporte"
    // * @param fdecReporte el/la fdecReporte para asignar el valor
    // */
    // public void setFdecReporte(FDECReporte fdecReporte) {
    // this.fdecReporte = fdecReporte;
    // }
}
