/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 4 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.models;

import java.io.Serializable;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class Rol implements Serializable {
    private static final long serialVersionUID = 1L;
    private String nombreRol;

    /**
     * Crea una nueva instancia de la clase Rol
     */
    public Rol() {
    }

    /**
     * Crea una nueva instancia de la clase Rol
     * @param nombreRol
     */
    public Rol(String nombreRol) {
        super();
        this.nombreRol = nombreRol;
    }

    /**
     * Obtiene el atributo de clase: "nombreRol"
     * @return el/la nombreRol
     */
    public String getNombreRol() {
        return this.nombreRol;
    }

    /**
     * Asigna valor al atributo de clase: "nombreRol"
     * @param nombreRol el/la nombreRol para asignar el valor
     */
    public void setNombreRol(String nombreRol) {
        this.nombreRol = nombreRol;
    }
}
