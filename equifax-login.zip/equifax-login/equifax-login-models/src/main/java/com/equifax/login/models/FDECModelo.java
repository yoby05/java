/*
 * Equifax Ecuador C.A. Sistema: Fast Decision Creado: 4 sep. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author yxh24
 * @version $Revision: $
 */
@Entity
// @Audited(withModifiedFlag = true)
@Table(name = "FDEC_Modelo")
public class FDECModelo implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    private FDECModeloPK id;
    @Column(name = "IdModelo")
    private Long idModelo;
    @Column(name = "Tipo")
    private String tipo;
    @Column(name = "Persona")
    private String persona;
    @Column(name = "Version")
    private String version;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdReporteProyecto")
    private FDECReporte modeloReporte;

    /**
     * Crea una nueva instancia de la clase FDECModelo
     */
    public FDECModelo() {
        super();
    }

    /**
     * Crea una nueva instancia de la clase FDECModelo
     * @param id
     */
    public FDECModelo(FDECModeloPK id) {
        super();
        this.id = id;
    }

    /**
     * Obtiene el atributo de clase: "id"
     * @return el/la id
     */
    public FDECModeloPK getId() {
        return this.id;
    }

    /**
     * Asigna valor al atributo de clase: "id"
     * @param id el/la id para asignar el valor
     */
    public void setId(FDECModeloPK id) {
        this.id = id;
    }

    /**
     * Obtiene el atributo de clase: "idModelo"
     * @return el/la idModelo
     */
    public Long getIdModelo() {
        return this.idModelo;
    }

    /**
     * Asigna valor al atributo de clase: "idModelo"
     * @param idModelo el/la idModelo para asignar el valor
     */
    public void setIdModelo(Long idModelo) {
        this.idModelo = idModelo;
    }

    /**
     * Obtiene el atributo de clase: "tipo"
     * @return el/la tipo
     */
    public String getTipo() {
        return this.tipo;
    }

    /**
     * Asigna valor al atributo de clase: "tipo"
     * @param tipo el/la tipo para asignar el valor
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * Obtiene el atributo de clase: "persona"
     * @return el/la persona
     */
    public String getPersona() {
        return this.persona;
    }

    /**
     * Asigna valor al atributo de clase: "persona"
     * @param persona el/la persona para asignar el valor
     */
    public void setPersona(String persona) {
        this.persona = persona;
    }

    /**
     * Obtiene el atributo de clase: "version"
     * @return el/la version
     */
    public String getVersion() {
        return this.version;
    }

    /**
     * Asigna valor al atributo de clase: "version"
     * @param version el/la version para asignar el valor
     */
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * Obtiene el atributo de clase: "modeloReporte"
     * @return el/la modeloReporte
     */
    public FDECReporte getModeloReporte() {
        return this.modeloReporte;
    }

    /**
     * Asigna valor al atributo de clase: "modeloReporte"
     * @param modeloReporte el/la modeloReporte para asignar el valor
     */
    public void setModeloReporte(FDECReporte modeloReporte) {
        this.modeloReporte = modeloReporte;
    }
}
