/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 26 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import com.equifax.login.notaciones.SecuenciaAutomatica;

/**
 * The primary key class for the CARGA database table.
 */
@Embeddable
public class RFRInstitucionPK implements Serializable {
    private static final long serialVersionUID = 1L;
    @Column(name = "COD_INSTITUCION")
    @SecuenciaAutomatica
    private Long codigoInstitucion;

    /**
     * Crea una nueva instancia de la clase CargaPK
     */
    public RFRInstitucionPK() {
    }

    /**
     * Crea una nueva instancia de la clase RFRInstitucionPK
     * @param codigoInstitucion
     */
    public RFRInstitucionPK(Long codigoInstitucion) {
        super();
        this.codigoInstitucion = codigoInstitucion;
    }

    /**
     * Obtiene el atributo de clase: "codigoInstitucion"
     * @return el/la codigoInstitucion
     */
    public Long getCodigoInstitucion() {
        return this.codigoInstitucion;
    }

    /**
     * Asigna valor al atributo de clase: "codigoInstitucion"
     * @param codigoInstitucion el/la codigoInstitucion para asignar el valor
     */
    public void setCodigoInstitucion(Long codigoInstitucion) {
        this.codigoInstitucion = codigoInstitucion;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RFRInstitucionPK)) {
            return false;
        }
        RFRInstitucionPK castOther = (RFRInstitucionPK) other;
        return (this.codigoInstitucion == castOther.codigoInstitucion);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int hash = 17;
        if (this.codigoInstitucion != null) {
            hash = hash * prime + ((int) (this.codigoInstitucion ^ (this.codigoInstitucion >>> 32)));
        }
        return hash;
    }
}