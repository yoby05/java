/*
 * Equifax Ecuador C.A. Sistema: Fast Decision Creado: 4 sep. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.models;

import java.io.Serializable;

import javax.persistence.Column;

import com.equifax.login.notaciones.SecuenciaAutomatica;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class FDECProyectoPK implements Serializable {
    private static final long serialVersionUID = 1L;
    @Column(name = "IdProyecto")
    @SecuenciaAutomatica
    private Long idProyecto;

    /**
     * Crea una nueva instancia de la clase CargaPK
     */
    public FDECProyectoPK() {
    }

    /**
     * Crea una nueva instancia de la clase FEDCProyectoPK
     * @param idProyecto
     */
    public FDECProyectoPK(Long idProyecto) {
        super();
        this.idProyecto = idProyecto;
    }

    /**
     * Obtiene el atributo de clase: "idProyecto"
     * @return el/la codigoProyecto
     */
    public Long getIdProyecto() {
        return this.idProyecto;
    }

    /**
     * Asigna valor al atributo de clase: "idProyecto"
     * @param idProyecto el/la idProyecto para asignar el valor
     */
    public void setIdProyecto(Long idProyecto) {
        this.idProyecto = idProyecto;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof FDECProyectoPK)) {
            return false;
        }
        FDECProyectoPK castOther = (FDECProyectoPK) other;
        return (this.idProyecto == castOther.idProyecto);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int hash = 17;
        if (this.idProyecto != null) {
            hash = hash * prime + ((int) (this.idProyecto ^ (this.idProyecto >>> 32)));
        }
        return hash;
    }
}
