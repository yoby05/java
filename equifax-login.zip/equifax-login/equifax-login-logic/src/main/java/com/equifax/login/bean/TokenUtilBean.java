/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 9 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean;

import java.io.IOException;
import java.text.ParseException;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jwt.JWTClaimsSet;

/**
 * @author yxh24
 * @version $Revision: $
 */
public interface TokenUtilBean {
    /**
     * Permite generar el token para al acceso a la plataforma
     * @param login Es el nombre de usuario
     * @param tokenLogin Token que se generea en el servicio del login
     * @param roles Roles de acceso del usuario
     * @return Token nuevo
     * @throws JOSEException
     */
    String generarTokenDeAcceso(String login, String tokenLogin, String roles) throws JOSEException;

    /**
     * Realiza la desencriptacion del token
     * @param token desencriptado
     * @return JWTClaimsSet
     * @throws ParseException
     * @throws JOSEException
     * @throws IOException
     */
    JWTClaimsSet desencriptorToken(String token) throws ParseException, JOSEException, IOException;

    /**
     * Obtiene el codigo del token
     * @param token
     * @return token Serializado
     */
    String obtenerTokenSerializado(String token);
}
