/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 26 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.utiles;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateUtils;

import com.equifax.login.enumeradores.EnumFormatoFecha;
import com.equifax.login.enumeradores.EnumMes;

/**
 * <p>
 * <strong>DESCRIPCION:</strong> <blockquote>Contiene metodos utilitarios para obtener instancias, comparar, manipular y validar
 * las fechas que se utilizan en los servicios (EJB) y en los controladores (Backing Bean).</blockquote>
 * </p>
 * <p>
 * <strong>NOTAS IMPORTANTES:</strong>
 * <ul>
 * <li>No se puede utilizar <code>new Date()</code> para crear una instancia de la fecha, en su lugar se debe utilizar el metodo
 * <code>FechaUtil.hoy()</code> cuando se quiere la fecha actual sin horas, minutos y segundos ( 01-01-2016 00:00:00) o el metodo
 * <code>FechaUtil.ahora()</code> para obtener la fecha actual con la hora, minuto y segundo del instante ( 01-01-2015 12:44:31 ).
 * </li>
 * <li>No se debe utilizar ninguna otra clase utilitarias como <code>DateUtils</code>, <code>DateValidator</code>,
 * <code>SimpleDateFormat</code>, etc. En su lugar se deben crear metodos dentro del utilitario.</li>
 * </ul>
 * </p>
 * @author SMART IT DEVELOPMENT
 * @version $Revision: $
 */
public final class FechaUtil {
    /**
     * Constructor por defecto.
     */
    private FechaUtil() {
    }

    /**
     * Retorna una nueva fecha donde se incrementa/resta un numero de minutos a una fecha (fechaOriginal).
     * @param fechaOriginal Fecha sobre la cual se opera la adicion/resta de minutos.
     * @param cantidadMinutos La cantidad de minutos por incrementar/restar; no debe ser nulo.
     * @return Nueva fecha con el incremento/resta de minutos a la fechaOriginal.
     */
    public static Date agregarMinutos(Date fechaOriginal, int cantidadMinutos) {
        return DateUtils.addMinutes(fechaOriginal, cantidadMinutos);
    }

    /**
     * Retorna una nueva fecha donde se incrementa/resta un numero de dias a una fecha (fechaOriginal).
     * @param fechaOriginal Fecha sobre la cual se opera la adicion/resta de dias.
     * @param cantidadDias La cantidad de dias por incrementar/restar; no debe ser nulo.
     * @return Nueva fecha con el incremento/resta de dias a la fechaOriginal.
     */
    public static Date agregarDias(Date fechaOriginal, int cantidadDias) {
        return DateUtils.addDays(fechaOriginal, cantidadDias);
    }

    /**
     * Retorna una nueva fecha donde se incrementa/resta un numero de meses a una fecha (fechaOriginal).
     * @param fechaOriginal Fecha sobre la cual se opera la adicion/resta de meses.
     * @param cantidadMeses La cantidad de meses por incrementar/restar; no debe ser nulo.
     * @return Nueva fecha con el incremento/resta de meses a la fechaOriginal.
     */
    public static Date agregarMeses(Date fechaOriginal, int cantidadMeses) {
        return DateUtils.addMonths(fechaOriginal, cantidadMeses);
    }

    /**
     * Retorna una nueva fecha donde se incrementa/resta un numero de annos a una fecha (fechaOriginal).
     * @param fechaOriginal Fecha sobre la cual se opera la adicion/resta de anios.
     * @param cantidadAnios La cantidad de annios por incrementar/restar.
     * @return Nueva fecha con el incremento/resta de annos a la fechaOriginal.
     */
    public static Date agregarAnios(Date fechaOriginal, int cantidadAnios) {
        return DateUtils.addYears(fechaOriginal, cantidadAnios);
    }

    /**
     * Si la fecha que se compara es anterior a la fecha base
     * @param fechaCompara fecha que se desea comparar
     * @param fechaBase fecha base de la comparacion
     * @return Si la fecha que se compara es anterior a la fecha base
     */
    public static boolean anterior(Date fechaCompara, Date fechaBase) {
        return fechaCompara.before(fechaBase);
    }

    /**
     * Si la fecha que se compara es anterior/igual a la fecha base
     * @param fechaCompara fecha que se desea comparar
     * @param fechaBase fecha base de la comparacion
     * @return Si la fecha que se compara es anterior/igual a la fecha base
     */
    public static boolean anteriorIgual(Date fechaCompara, Date fechaBase) {
        return !fechaCompara.after(fechaBase);
    }

    /**
     * Si la fecha que se compara es igual a la fecha base
     * @param fechaCompara fecha que se desea comparar
     * @param fechaBase fecha base de la comparacion
     * @return Si la fecha que se compara es igual a la fecha base
     */
    public static boolean igual(Date fechaCompara, Date fechaBase) {
        return fechaCompara.equals(fechaBase);
    }

    /**
     * Si la fecha que se compara es posterior a la fecha base
     * @param fechaCompara fecha que se desea comparar
     * @param fechaBase fecha base de la comparacion
     * @return Si la fecha que se compara es posterior a la fecha base
     */
    public static boolean posterior(Date fechaCompara, Date fechaBase) {
        return fechaCompara.after(fechaBase);
    }

    /**
     * Si la fecha que se compara es posterior/igual a la fecha base
     * @param fechaCompara fecha que se desea comparar
     * @param fechaBase fecha base de la comparacion
     * @return Si la fecha que se compara es posterior/igual a la fecha base
     */
    public static boolean posteriorIgual(Date fechaCompara, Date fechaBase) {
        return !fechaCompara.before(fechaBase);
    }

    /**
     * Obtiene la zona horaria.
     * @return Zona horaria.
     */
    public static TimeZone timeZone() {
        return Calendar.getInstance().getTimeZone();
    }

    /**
     * Obtiene la fecha completa del instante cuando es invocado (annio, mes, dia, hora, minuto, segundo, etc.).
     * @return Fecha completa (annio, mes, dia, hora, minuto, segundo, etc.).
     */
    public static Date ahora() {
        return Calendar.getInstance().getTime();
    }

    /**
     * Obtiene la fecha del dia cuando es invocado (annio, mes y dia).
     * @return Fecha del dia con valores del annio, mes y dia, el resto de componentes de la fecha redondeados a cero (Hora,
     *         minuto, segundo, etc.).
     */
    public static Date hoy() {
        return DateUtils.truncate(Calendar.getInstance().getTime(), Calendar.DAY_OF_MONTH);
    }

    /**
     * Convierte un tipo de dato <code>Date</code> al tipo de dato <code>Calendar</code>.
     * @param fecha Fecha que se requiere convertir a Calendar.
     * @return Calendar instanciado con la fecha.
     */
    public static Calendar obtenerCalendario(Date fecha) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fecha);
        return calendar;
    }

    /**
     * Redondea los valores de la hora, minuto, segundo, etc. a cero, de una fecha determinada.
     * @param fecha Fecha a redondear la hora, minuto, segundo, etc.
     * @return Fecha con valores del annio, mes y dia, el resto de componentes de la fecha redondeados a cero (Hora, minuto,
     *         segundo, etc.).
     */
    public static Date truncarDia(Date fecha) {
        return DateUtils.truncate(fecha, Calendar.DAY_OF_MONTH);
    }

    /**
     * Redondea los valores de una fecha a un nivel definido en la clase <code>Calendar</code>.
     * @param fecha Fecha a redondear
     * @param nivelCalendar Nivel definido en la clase <code>Calendar</code>. Ejemplo: Calendar.DAY_OF_MONTH.
     * @return Fecha con valores redondeados segun el nivel
     */
    public static Date truncar(Date fecha, int nivelCalendar) {
        return DateUtils.truncate(fecha, nivelCalendar < 0 ? Calendar.SECOND : nivelCalendar);
    }

    /**
     * Obtiene el ultimo dia de la semana a la que pertenece una fecha determinada(<code>fechaBase</code>).
     * @param fechaBase Fecha base para la busqueda del ultimo dia de la semana a la que pertenece.
     * @return Fecha del ultimo dia de la semana a la que pertenece la fechaBase.
     */
    public static Date obtenerFechaUltimoDiaSemana(Date fechaBase) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fechaBase);
        while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
            calendar.add(Calendar.DATE, 1);
        }
        return calendar.getTime();
    }

    /**
     * Obtiene el primer dia de la semana a la que pertenece una fecha determinada(<code>fechaBase</code>).
     * @param fechaBase Fecha base para la busqueda del primer dia de la semana a la que pertenece.
     * @return Fecha del primer dia de la semana a la que pertenece la fechaBase.
     */
    public static Date obtenerFechaPrimerDiaSemana(Date fechaBase) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fechaBase);
        while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
            calendar.add(Calendar.DATE, -1);
        }
        return calendar.getTime();
    }

    /**
     * Obtiene el ultimo dia del mes a la que pertenece una fecha determinada(<code>fechaBase</code>).
     * @param fechaBase Fecha base para la busqueda del ultimo dia del mes a la que pertenece.
     * @return Fecha del ultimo dia del mes a la que pertenece la fechaBase.
     */
    public static Date obtenerFechaUltimoDiaMes(Date fechaBase) {
        Calendar calendar = devolverFechaDiaMes(fechaBase);
        calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        return calendar.getTime();
    }

    /**
     * Obtiene el primer dia del mes a la que pertenece una fecha determinada(<code>fechaBase</code>).
     * @param fechaBase Fecha base para la busqueda del primer dia del mes a la que pertenece.
     * @return Fecha del primer dia del mes a la que pertenece la fechaBase.
     */
    public static Date obtenerFechaPrimerDiaMes(Date fechaBase) {
        Calendar calendar = devolverFechaDiaMes(fechaBase);
        calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
        return calendar.getTime();
    }

    /**
     * Obtiene el dia del mes a la que pertenece
     * @param fechaBase Fecha base para la busqueda del dia del mes a la que pertenece
     * @return Calendar
     */
    private static Calendar devolverFechaDiaMes(Date fechaBase) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fechaBase);
        return calendar;
    }

    /**
     * Obtiene el numero de dias que existen entre un rango de fechas(fechaDesde, fechaHasta).
     * @param fechaInicio Fecha inicial del rango.
     * @param fechaFin Fecha final del rango.
     * @return Numero de dias entre el rango de fechas
     */
    public static int diasEntreFechas(Date fechaInicio, Date fechaFin) {
        Date resultado = new Date(
                obtenerCalendario(fechaFin).getTimeInMillis() - FechaUtil.obtenerCalendario(fechaInicio).getTimeInMillis());
        long dia = 24 * 60 * 60 * 1000;
        long resultadoL = resultado.getTime() / dia;
        return (int) resultadoL;
    }

    /**
     * Obtiene el numero de dias (plazo) que existen entre un rango de fechas utilizando una base de calculo de 30 o 31 dias.
     * @param fechaDesde Fecha inicial del rango.
     * @param fechaHasta Fecha final del rango.
     * @param baseCalculo Opcional. Cuando es verdadero utiliza para el calculo del plazo la <strong>Base Real (31 dias)</strong>;
     *        caso contrario utiliza <strong>Base 30 (30 dias)</strong>. Por omision utiliza la <strong>Base Real (31
     *        dias)</strong>.
     * @return Numero de dias entre el rango de fechas
     */
    public static int plazoEntreFechas(Date fechaDesde, Date fechaHasta, Boolean... baseCalculo) {
        Boolean real = (baseCalculo != null && baseCalculo.length > 0) ? baseCalculo[0] : Boolean.TRUE;
        if (real) {
            return diasEntreFechas(fechaDesde, fechaHasta) + 1;
        }
        // Calculos Base 30
        Calendar fechaInicio = obtenerCalendario(fechaDesde);
        Calendar fechaFin = obtenerCalendario(fechaHasta);
        int anos = fechaFin.get(Calendar.YEAR) - fechaInicio.get(Calendar.YEAR);
        int meses = fechaFin.get(Calendar.MONTH) - fechaInicio.get(Calendar.MONTH);
        int dia1 = fechaInicio.get(Calendar.DATE);
        int dia2 = fechaFin.get(Calendar.DATE);
        if (fechaInicio.get(Calendar.DATE) == 31
                || (fechaInicio.get(Calendar.MONTH) == Calendar.FEBRUARY && fechaInicio.get(Calendar.DATE) >= 28)) {
            dia1 = 30;
        }
        if (fechaFin.get(Calendar.DATE) == 31
                || (fechaFin.get(Calendar.MONTH) == Calendar.FEBRUARY && fechaFin.get(Calendar.DATE) >= 28)) {
            dia2 = 30;
        }
        int dias = dia2 - dia1;
        int diasLab = anos * 360 + meses * 30 + dias;
        return diasLab + 1;
    }

    /**
     * Indica si el anno de la fecha enviada como parametro es bisiesto
     * @param fecha Fecha para verificar el anno.
     * @return Verdadero si es bisiesto; caso contrario falso.
     */
    public static Boolean esAnioBisiesto(Date fecha) {
        Date fechaAux = fecha == null ? hoy() : fecha;
        Calendar calendar = obtenerCalendario(fechaAux);
        int anio = calendar.get(Calendar.YEAR);
        return (anio % 4 == 0) && ((anio % 100 != 0) || (anio % 400 == 0));
    }

    /**
     * Convierte una fecha a un string segun un formato especificado
     * @param fecha fecha a convertir
     * @param mascara mascara con el formato a convertir la fecha
     * @return la fecha convertida al formato especificado en la mascara
     */
    public static String convertirFechaString(Date fecha, EnumFormatoFecha... mascara) {
        DateFormat fechaHora;
        if (mascara != null && mascara.length > 0) {
            fechaHora = new SimpleDateFormat(mascara[0].formato());
        } else {
            fechaHora = new SimpleDateFormat(EnumFormatoFecha.FECHA.formato());
        }
        return fechaHora.format(fecha);
    }

    /**
     * Convierte una fecha a un string segun un formato especificado
     * @param fechaString
     * @param mascara mascara con el formato a convertir la fecha
     * @return la fecha convertida al formato especificado en la mascara
     */
    public static Date convertirStringFecha(String fechaString, EnumFormatoFecha... mascara) {
        SimpleDateFormat formatter;
        if (mascara != null && mascara.length > 0) {
            formatter = new SimpleDateFormat(mascara[0].formato());
        } else {
            formatter = new SimpleDateFormat(EnumFormatoFecha.FECHA.formato());
        }
        try {
            return formatter.parse(fechaString);
        } catch (ParseException e) {
            e.printStackTrace();
            return FechaUtil.hoy();
        }
    }

    /**
     * Devuelve el mes/año de una fecha en formato String
     * @param fechaFactura fecha base para obtener mes y año
     * @return el mes/año de la fecha en formato String
     */
    public static String getFechaMesYearString(Date fechaFactura) {
        String fecha = FechaUtil.convertirFechaString(fechaFactura, EnumFormatoFecha.FECHA);
        String mes = String.valueOf(fecha.charAt(3)).concat(String.valueOf(fecha.charAt(4)));
        EnumMes valor = null;
        Calendar c1 = Calendar.getInstance();
        c1.setTime(fechaFactura);
        // c1.get(Calendar.MONTH);
        // c1.get(Calendar.DAY_OF_MONTH);
        switch (Integer.valueOf(mes)) {
            case 1:
                valor = EnumMes.ENE;
                break;
            case 2:
                valor = EnumMes.FEB;
                break;
            case 3:
                valor = EnumMes.MAR;
                break;
            case 4:
                valor = EnumMes.ABR;
                break;
            case 5:
                valor = EnumMes.MAY;
                break;
            case 6:
                valor = EnumMes.JUN;
                break;
            case 7:
                valor = EnumMes.JUL;
                break;
            case 8:
                valor = EnumMes.AGO;
                break;
            case 9:
                valor = EnumMes.SEP;
                break;
            case 10:
                valor = EnumMes.OCT;
                break;
            case 11:
                valor = EnumMes.NOV;
                break;
            default:
                valor = EnumMes.DIC;
                break;
        }
        return valor.getDescripcion().concat("/").concat(String.valueOf(c1.get(Calendar.YEAR)));
    }
}
