/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 26 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean.impl;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.equifax.login.bean.FDECProyectoBean;
import com.equifax.login.dao.FDECProyectoDao;
import com.equifax.login.models.FDECProyecto;
import com.equifax.login.models.FDECProyectoPK;

/**
 * @author yxh24
 */
@Stateless
public class FDECProyectoBeanImp implements FDECProyectoBean {
    @Inject
    private FDECProyectoDao fdecProyectoDao;

    /**
     * Crea una nueva instancia de la clase RFRInstitucionBeanImp
     */
    public FDECProyectoBeanImp() {
    }

    /**
     * Permite Obtener FDECProyecto por Identificador
     * @param fdecProyectoPK Identificador PK de FDECProyecto
     * @return FDECProyecto
     */
    @Override
    public FDECProyecto obtenerFDECProyectoPorIdentificadorPK(FDECProyectoPK fdecProyectoPK) {
        return this.fdecProyectoDao.obtenerFDECProyectoPorIdentificadorPK(fdecProyectoPK);
    }

    /**
     * Crear nuevo FDECProyecto
     * @param fdecProyecto
     * @return Mensaje confirmacion
     */
    @Override
    public String crearFDECProyecto(FDECProyecto fdecProyecto) {
        return this.fdecProyectoDao.crearFDECProyecto(fdecProyecto);
    }

    /**
     * Modificar FDECProyecto
     * @param fdecProyecto
     * @return Mensaje confirmacion
     */
    @Override
    public String modificarFDECProyecto(FDECProyecto fdecProyecto) {
        return this.fdecProyectoDao.modificarFDECProyecto(fdecProyecto);
    }
}
