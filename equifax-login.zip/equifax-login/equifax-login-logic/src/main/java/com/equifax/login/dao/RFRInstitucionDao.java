/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.dao;

import java.util.List;

import com.equifax.login.models.RFRInstitucion;
import com.equifax.login.models.RFRInstitucionPK;

/**
 * @author yxh24
 * @version $Revision: $
 */
public interface RFRInstitucionDao {
    /**
     * Permite Obtener RFRInstitucion por Identificador
     * @param identificadorInstitucion Identificador PK de RFRInstitucion
     * @return RFRInstitucion
     */
    RFRInstitucion obtenerInstitucionPorIdentificadorPK(RFRInstitucionPK identificadorInstitucion);

    /**
     * Obtiene todas las intituciones por nombre de su tipo
     * @param nombreTipoInstitucion Nombre de tipo del RFRInstitucion
     * @return List<RFRInstitucion>
     */
    List<RFRInstitucion> obtenerInstitucionesPorNombreTipo(String nombreTipoInstitucion);

    /**
     * Obtiene todas las intituciones por rango de Identificadores
     * @param codigoInstituciones Identificadores de RFRInstitucion
     * @return List<RFRInstitucion>
     */
    List<RFRInstitucion> obtenerInstitucionesPorCodigoInstitucionesPK(List<Long> codigoInstituciones);
}
