/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 3 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.utiles;

/**
 * @author yxh24
 * @version $Revision: $
 */
public final class RutaServiciosWebUtil {
    /**
     * Ruta Raiz entidad RFRInstitucion
     */
    public static final String RUTA_RAIZ_INSTITUCION = "/rfrInstitucion";
    /**
     * Ruta Raiz entidad Usuario
     */
    public static final String RUTA_RAIZ_USUARIO = "/usuario";
    /**
     * Ruta Para consultar por identificador POST
     */
    public static final String RUTA_CONSULTAR_POR_IDENTIFICADOR = "/consultarPorIdentificador";
    /**
     * Ruta Para consultar por identificadores
     */
    public static final String RUTA_CONSULTAR_POR_IDENTIFICADORES = "/consultarPorIdentificadores";
    /**
     * Ruta Para consultar por identificador GET
     */
    public static final String RUTA_CONSULTAR_POR_IDENTIFICADOR_GET = "/consultarPorIdentificador/{id}";
    /**
     * Ruta Para consultar por nombre del tipoPOST
     */
    public static final String RUTA_CONSULTAR_POR_NOMBRE_TIPO_POST = "/consultarPorNombreTipo";
    /**
     * Ruta Para generar token de usuario POST
     */
    public static final String RUTA_LOGIN_GENERAR_TOKEN_POST = "/login";
}
