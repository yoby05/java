/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.utiles;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Define y produce el contexto de persistencia para su obtencion por CDI
 * @author yxh24
 */
public class ContextoPersistencia {
    /**
     * Contexto de persistencia de conexion a BD Oracle
     */
    // @PersistenceContext(unitName = "OracleDS")
    // public EntityManager entityManagerOracle;
    /**
     * Contexto de persistencia de conexion a BD SQLServer
     */
    @PersistenceContext(unitName = "SQLServerDS")
    public EntityManager entityManagerSQLServer;

    /**
     * Produce gestor de entidades
     * @param ip punto de inyeccion
     * @return Gestor de Entidades
     */
    // @Produces
    // public EntityManager getEmOracle(InjectionPoint ip) {
    // return this.entityManagerOracle;
    // }
    /**
     * Produce gestor de entidades
     * @param ip punto de inyeccion
     * @return Gestor de Entidades
     */
    @Produces
    public EntityManager getEmSQLServer(InjectionPoint ip) {
        return this.entityManagerSQLServer;
    }
}
