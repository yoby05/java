/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.enumeradores;

import java.io.Serializable;

/**
 * @author yxh24
 * @version $Revision: $
 */
public enum EnumCodigoLogin implements Serializable {
    /**
     * Ingreso exitoso
     */
    CODIGO_1000("Ingreso exitoso", "1000"),
    /**
     * Usuario y/o password incorrecto
     */
    CODIGO_1002("Usuario y/o password incorrecto", "1002"),
    /**
     * El usuario esta eliminado o suspendido
     */
    CODIGO_1003("El usuario esta eliminado o suspendido", "1003"),
    /**
     * El usuario existe pero no tiene un perfil asignado
     */
    CODIGO_1011("El usuario existe pero no tiene un perfil asignado", "1011"),
    /**
     * Servicios del Token no encontrados
     */
    CODIGO_1027("Servicios del Token no encontrados", "1027"),
    /**
     * Servicio Token devuelve una respuesta vacia
     */
    CODIGO_1028("Servicio Token devuelve una respuesta vacia", "1028"),
    /**
     * Clave Expirada
     */
    CODIGO_1031("Clave Expirada", "1031"),
    /**
     * Bloqueado por Intentos Fallidos
     */
    CODIGO_1033("Bloqueado por Intentos Fallidos", "1033");
    /**
     * /** Mensaje que corresponde al codigo
     */
    private String descripcion;
    /**
     * Valor que corresponde al codigo
     */
    private String valor;

    /**
     * Crea una nueva instancia de la clase EnumCodigoLogin
     * @param descripcion
     * @param valor
     */
    private EnumCodigoLogin(String descripcion, String valor) {
        this.descripcion = descripcion;
        this.valor = valor;
    }

    /**
     * Obtiene el atributo de clase: "descripcion"
     * @return el/la descripcion
     */
    public String getDescripcion() {
        return this.descripcion;
    }

    /**
     * Obtiene el atributo de clase: "valor"
     * @return el/la valor
     */
    public String getValor() {
        return this.valor;
    }
}
