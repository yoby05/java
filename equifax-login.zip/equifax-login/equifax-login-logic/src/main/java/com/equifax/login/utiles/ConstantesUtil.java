/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.utiles;

/**
 * @author yxh24
 * @version $Revision: $
 */
public final class ConstantesUtil {
    /**
     * CONSTANTE IDENTIFICA SI
     */
    public static final String CONDICION_SI = "SI";
    /**
     * CONSTANTE IDENTIFICA NO
     */
    public static final String CONDICION_NO = "NO";
    /**
     * CONSTANTE IDENTIFICA ACTIVO
     */
    public static final String CONDICION_ACTIVO = "ACT";
    /**
     * CONSTANTE IDENTIFICAR INACTIVO
     */
    public static final String CONDICION_INACTIVO = "INA";
    /**
     * PARA CASTEAR EL OBJETO DE UNA LISTA
     */
    public static final String UNCHECKED = "unchecked";
    /**
     * VARIABLE PARA IDENTIFICAR ELIMINADO LOGICO
     */
    public static final String ELIMINADO = "eliminado";
    /**
     * CODIFICACION UTF-8
     */
    public static final String UTF_8 = ";charset=utf-8";
    /**
     * TRANSFORMAR FECHA
     */
    public static final String STRING_FORMATO_GMT_FECHA_DIA_MES_ANIO = "dd/MM/yyyy";
    /**
     * CODIGO DEL USUARIO
     */
    public static final String CODIGO_USUARIO = "codigoUsuario";
    /**
     * CODIGO DE LA INSTITUCION
     */
    public static final String CODIGO_INSTITUCION = "codigoInstitucion";
    /**
     * NOMBRE DE LA INSTITUCION
     */
    public static final String NOMBRE_TIPO_INSTITUCION = "nombreTipoInstitucion";
    /**
     * JSON GENERADO AL CONSUMIR SERVICIO WEB LOGIN
     */
    public static final String JSON_GEN_TOKEN = "jsonGenerarToken";
    /**
     * RESPUESTA OBJETO AL CONSUMIR SERVICIO WEB LOGIN
     */
    public static final String RESP_OBJETO = "objectRespuesta";
    /**
     * NOMBRE DE PROPIEDAD EQUIFAX UTILES
     */
    public static final String EQUIFAX_UTIL = "EquifaxUtils";
    /**
     * PARAMETRO DEL SERVICIO OBTENER LOGIN
     */
    public static final String PARAMETRO_OBTENER_LOGIN = "EQUIFAX.PARAMETRO.OBTENER_LOGIN";
    /**
     * PARAMETRO LLAVE DESENCRIPTOR
     */
    public static final String PARAMETRO_LLAVE_DESENCRIPTOR = "EQUIFAX.TOKEN.LLAVE_DESENCRIPTADOR";
    /**
     * ETIQUETA CORRESPONDE AL MENSAJE DE LA PETICION
     */
    public static final String MENSAJE = "mensaje";
    /**
     * ETIQUETA CORRESPONDE AL CODIGO DE LA PETICION
     */
    public static final String CODIGO = "codigo";
    /**
     * RANGO DE CODIGOS
     */
    public static final String CODIGOS = "codigos";
    /**
     * HEADER DE GENERACION DE TOKEN
     */
    public static final String TOKEN_EQUIFAX = "Equifax ";
}
