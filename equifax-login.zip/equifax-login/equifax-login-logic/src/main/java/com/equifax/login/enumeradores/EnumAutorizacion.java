/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 27 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.enumeradores;

import java.io.Serializable;

/**
 * @author yxh24
 * @version $Revision: $
 */
public enum EnumAutorizacion implements Serializable {
    /**
     * Enum Error al autenticar el usuario
     */
    ERROR_AUTENTICADO("No se pudo autenticar el usuario"),
    /**
     * Enum Error No tiene permiso acceder al recurso
     */
    ERROR_ACCESO("El usuario no tiene permiso para acceder al recurso solicitado");
    private String descripcion;

    /**
     * Crea una nueva instancia de la clase EnumAutorizacion
     * @param descripcion
     */
    private EnumAutorizacion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene el atributo de clase: "descripcion"
     * @return el/la descripcion
     */
    public String getDescripcion() {
        return this.descripcion;
    }
}
