/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 26 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.enumeradores;

import java.io.Serializable;

/**
 * @author jrper
 */
public enum EnumFormatoFecha implements Serializable {
    /**
     * El elemento FECHA cuyo formato es "dd-MM-yyyy".
     */
    FECHA_REP("MM/dd/yyyy"),
    /**
     * El elemento FECHA cuyo formato es "dd-MM-yyyy".
     */
    FECHA_TIME("dd-MM-yyyy HH:mm:ss"),
    /**
     * El elemento FECHA cuyo formato es "dd-MM-yyyy".
     */
    FECHA("dd-MM-yyyy"),
    /**
     * El elemento FECHA cuyo formato es "dd-MM-yyyy".
     */
    FECHA_EN("yyyy-MM-dd");
    /**
     * Propiedad que contiene el formato para la fecha.
     */
    private final String formato;

    /**
     * Constructor por defecto de la enumeracion.
     * @param formato Formato para desplegar la fecha.
     */
    EnumFormatoFecha(String formato) {
        this.formato = formato;
    }

    /**
     * Retorna el formato asociado al elemento de la enumeracion.
     * @return formato asociado al elemento de la enumeracion.
     */
    public String formato() {
        return this.formato;
    }
}
