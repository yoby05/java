/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.utiles;

/**
 * @author yxh24
 * @version $Revision: $
 */
import java.util.ResourceBundle;

/**
 * @author Yoan Hernandez
 */
public final class PropiedadesUtil {
    /**
     * Nombre de la propiedad
     */
    private static ResourceBundle propiedad = ResourceBundle.getBundle(ConstantesUtil.EQUIFAX_UTIL);

    /**
     * Crea una nueva instancia de la clase PropiedadesUtil
     */
    public PropiedadesUtil() {
        super();
    }

    /**
     * Metodo que devuelve la propiedad en base a su codigo
     * @param llave Codigo de la propiedad
     * @return String
     */
    public static String obtenerPropiedad(String llave) {
        return propiedad.getString(llave);
    }
}
