/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.exepciones;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class WEBExepcion extends Exception {
    private static final long serialVersionUID = -8079749089547755244L;

    /**
     * Crea una nueva instancia de la clase WEBExepcion
     * @param message
     * @param cause
     */
    public WEBExepcion(final String message, final Throwable cause) {
        super(message, cause);
    }

    /**
     * Crea una nueva instancia de la clase WEBExepcion
     * @param message
     */
    public WEBExepcion(final String message) {
        super(message);
    }
}
