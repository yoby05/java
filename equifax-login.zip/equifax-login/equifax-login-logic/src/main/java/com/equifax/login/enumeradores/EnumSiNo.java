/**
 * Clase SiNoEnum.java 21/12/2015 Copyright 2015 Servicio de Rentas Internas. Todos los derechos reservados.
 */
package com.equifax.login.enumeradores;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author jada270709
 */
public enum EnumSiNo implements Serializable {
    /**
     * <p>
     * Campo con valor SI : SI
     * </p>
     */
    SI(Boolean.TRUE),
    /**
     * <p>
     * Campo con valor NO : NO
     * </p>
     */
    NO(Boolean.FALSE);
    /**
     *
     */
    public Boolean valor;

    /**
     * SiNo constructor
     */
    private EnumSiNo(Boolean valor) {
        this.setValor(valor);
    }

    /**
     * Get the VALOR property
     * @return Boolean
     */
    public Boolean getValor() {
        return this.valor;
    }

    /**
     * Set the VALOR property.
     * @param value the new value
     */
    public void setValor(Boolean value) {
        this.valor = value;
    }

    /**
     * Return the SiNo from a string value
     * @param value
     * @return SiNo enum object
     */
    public static EnumSiNo fromString(String value) {
        String newValue = value.toLowerCase();
        if ("si".equals(newValue)) {
            return EnumSiNo.SI;
        } else if ("no".equals(newValue)) {
            return EnumSiNo.NO;
        }
        // return valueOf(value);
        return null;
    }

    /**
     * Return a Collection of all literal values for this enumeration
     * @return Collection literal values
     */
    @SuppressWarnings("rawtypes")
    public static Collection literals() {
        final Collection<String> literals = new ArrayList<String>(values().length);
        for (int i = 0; i < values().length; i++) {
            literals.add(values()[i].name());
        }
        return literals;
    }
}
