/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 13 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean;

import java.text.ParseException;
import java.util.Map;

import javax.ws.rs.core.Response;

import com.equifax.login.models.Usuario;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jwt.JWTClaimsSet;

/**
 * @author yxh24
 * @version $Revision: $
 */
public interface UsuarioBean {
    /**
     * Permite obtener un usuario mediante un token
     * @param token Token de seguridad
     * @return JWTClaimsSet Entidad
     * @throws ParseException
     */
    Usuario obtenerUsuarioPorToken(JWTClaimsSet token) throws ParseException;

    /**
     * Obtiene la respuesta de acceso mediante el servicio web de login
     * @param usuario
     * @return Map Respuesta del servicio de validar login en la BD
     */
    Map<String, Object> servicioWEBLogin(Usuario usuario);

    /**
     * Valida la peticion web y controla la existencia si hay error
     * @param respuestaServicioWEbLogin Respuesta servicio web login
     * @param usuario Entidad Usuario
     * @return Response Respuesta
     * @throws JOSEException
     */
    Response autenticacionUsuario(Map<String, Object> respuestaServicioWEbLogin, Usuario usuario) throws JOSEException;
}
