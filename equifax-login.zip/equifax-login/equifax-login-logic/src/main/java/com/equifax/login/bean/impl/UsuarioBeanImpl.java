/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 13 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import com.equifax.login.bean.TokenUtilBean;
import com.equifax.login.bean.UsuarioBean;
import com.equifax.login.client.rest.LoginClienteRest;
import com.equifax.login.enumeradores.EnumCodigoLogin;
import com.equifax.login.models.Usuario;
import com.equifax.login.utiles.ConstantesUtil;
import com.equifax.login.utiles.PropiedadesUtil;
import com.equifax.login.utiles.ValidacionUtil;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jwt.JWTClaimsSet;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class UsuarioBeanImpl implements UsuarioBean {
    @Inject
    private LoginClienteRest loginClienteRest;
    @Inject
    private TokenUtilBean tokenBean;

    /**
     * Crea una nueva instancia de la clase UsuarioBeanImpl
     */
    public UsuarioBeanImpl() {
    }

    /**
     * Permite obtener un usuario mediante un token
     * @param token Token de seguridad
     * @return Usuario Entidad
     * @throws ParseException
     */
    @Override
    public Usuario obtenerUsuarioPorToken(JWTClaimsSet token) throws ParseException {
        Usuario usuario = new Usuario();
        List<String> roles = new ArrayList<String>();
        usuario.setNombreUsuario(token.getSubject());
        String rolesToken = token.getStringClaim("roles");
        roles = Arrays.asList(rolesToken.split(","));
        usuario.setRoles(roles);
        return usuario;
    }

    /**
     * Obtiene la respuesta de acceso mediante el servicio web de login
     * @param usuario Usuario de ingreso
     * @return Map Respuesta del servicio de validar login en la BD
     */
    @Override
    public Map<String, Object> servicioWEBLogin(Usuario usuario) {
        String nombreUsuario = usuario.getName();
        String passUsuario = usuario.getPassUsuario();
        String urlServicioWEB = PropiedadesUtil.obtenerPropiedad(ConstantesUtil.PARAMETRO_OBTENER_LOGIN);
        Map<String, Object> respuestaServicioLogin =
                this.loginClienteRest.obtenerLogin(nombreUsuario, passUsuario, urlServicioWEB);
        return respuestaServicioLogin;
    }

    /**
     * Valida la peticion web y controla la existencia si hay error
     * @param respuestaServicioWEbLogin Respuesta servicio web login
     * @param usuario Entidad Usuario
     * @return Response Respuesta
     * @throws JOSEException
     */
    @Override
    public Response autenticacionUsuario(Map<String, Object> respuestaServicioWEbLogin, Usuario usuario) throws JOSEException {
        /**
         * Codigo de validacion del usuario y password en la BD, si todo es correcto se genera el token
         */
        // String mensaje = ValidacionUtil.valString(respuestaServicioWEbLogin.get(ConstantesUtil.MENSAJE));
        String condigo = ValidacionUtil.valString(respuestaServicioWEbLogin.get(ConstantesUtil.CODIGO));
        if (condigo.equals(EnumCodigoLogin.CODIGO_1000.getValor())) {
            /**
             * Si el codigo es correcto para el login se genera el token de acceso
             */
            @SuppressWarnings(ConstantesUtil.UNCHECKED)
            Map<String, String> jsonGenerarToken =
                    (Map<String, String>) respuestaServicioWEbLogin.get(ConstantesUtil.JSON_GEN_TOKEN);
            String tokenLogin = jsonGenerarToken.get(ConstantesUtil.RESP_OBJETO);
            String nombreUsuario = usuario.getName();
            /**
             * Se invoca metodo para obtenet los roles del usuario
             */
            List<String> roles = new ArrayList<String>();
            /**
             * La lista se llena con los roles obtenidos de BD
             */
            roles.add("ADMIN");
            roles.add("OPERACIONES");
            String cadenaRoles = this.obtenerRolesUsuarios(roles);
            /**
             * Se genera el token
             */
            String token = this.tokenBean.generarTokenDeAcceso(nombreUsuario, tokenLogin, cadenaRoles);
            /**
             * Devolvemos el token en la cabecera "Autorizacion"
             */
            return Response.ok().header(HttpHeaders.AUTHORIZATION, ConstantesUtil.TOKEN_EQUIFAX + token).build();
        } else if (condigo.equals(EnumCodigoLogin.CODIGO_1002.getValor())) {
            return Response.status(Response.Status.UNAUTHORIZED)
                    .header(ConstantesUtil.MENSAJE, EnumCodigoLogin.CODIGO_1002.getDescripcion())
                    .build();
        } else if (condigo.equals(EnumCodigoLogin.CODIGO_1003.getValor())) {
            return Response.status(Response.Status.UNAUTHORIZED)
                    .header(ConstantesUtil.MENSAJE, EnumCodigoLogin.CODIGO_1003.getDescripcion())
                    .build();
        } else if (condigo.equals(EnumCodigoLogin.CODIGO_1011.getValor())) {
            return Response.status(Response.Status.UNAUTHORIZED)
                    .header(ConstantesUtil.MENSAJE, EnumCodigoLogin.CODIGO_1011.getDescripcion())
                    .build();
        } else if (condigo.equals(EnumCodigoLogin.CODIGO_1027.getValor())) {
            return Response.status(Response.Status.UNAUTHORIZED)
                    .header(ConstantesUtil.MENSAJE, EnumCodigoLogin.CODIGO_1027.getDescripcion())
                    .build();
        } else if (condigo.equals(EnumCodigoLogin.CODIGO_1028.getValor())) {
            return Response.status(Response.Status.UNAUTHORIZED)
                    .header(ConstantesUtil.MENSAJE, EnumCodigoLogin.CODIGO_1028.getDescripcion())
                    .build();
        } else if (condigo.equals(EnumCodigoLogin.CODIGO_1031.getValor())) {
            return Response.status(Response.Status.UNAUTHORIZED)
                    .header(ConstantesUtil.MENSAJE, EnumCodigoLogin.CODIGO_1031.getDescripcion())
                    .build();
        } else if (condigo.equals(EnumCodigoLogin.CODIGO_1033.getValor())) {
            return Response.status(Response.Status.UNAUTHORIZED)
                    .header(ConstantesUtil.MENSAJE, EnumCodigoLogin.CODIGO_1033.getDescripcion())
                    .build();
        } else {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
    }

    /**
     * Convierte una lista de Roles a una cadena de texto con los roles
     * @param roles Roles de acceso que tiene el usuario
     * @return String Cadena de roles
     */
    private String obtenerRolesUsuarios(List<String> roles) {
        String cadenaRoles = "";
        for (int i = 0; i < roles.size(); i++) {
            if (i + 1 == roles.size()) {
                cadenaRoles = cadenaRoles.concat(roles.get(i));
            } else {
                cadenaRoles = cadenaRoles.concat(roles.get(i) + ",");
            }
        }
        return cadenaRoles;
    }
}
