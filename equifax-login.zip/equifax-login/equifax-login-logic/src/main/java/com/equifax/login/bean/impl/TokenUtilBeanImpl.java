/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 9 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean.impl;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import com.equifax.login.bean.TokenUtilBean;
import com.equifax.login.enumeradores.EnumTokenError;
import com.equifax.login.utiles.ConstantesUtil;
import com.equifax.login.utiles.PropiedadesUtil;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class TokenUtilBeanImpl implements TokenUtilBean {
    /**
     * Obtengo la llave para encriptar y desencriptar el token
     */
    String llavePrivada = PropiedadesUtil.obtenerPropiedad(ConstantesUtil.PARAMETRO_LLAVE_DESENCRIPTOR);
    private static JWSHeader JWT_HEADER = new JWSHeader(JWSAlgorithm.HS256);

    /**
     * Constructor sin parametros
     */
    public TokenUtilBeanImpl() {
    }

    /**
     * Permite generar el token para al acceso a la plataforma
     * @param login Es el nombre de usuario
     * @param roles Roles de acceso del usuario
     * @param tokenLogin Token que se generea en el servicio del login
     * @return Token nuevo
     * @throws JOSEException
     */
    @Override
    public String generarTokenDeAcceso(String login, String tokenLogin, String roles) throws JOSEException {
        String token = "";
        /**
         * - Realizar login de la base con usuario y contrase�a y obtener sus roles
         */
        JWTClaimsSet.Builder claimsSet = new JWTClaimsSet.Builder();
        claimsSet.issuer("https://efxcentral.eis.equifax.com");
        claimsSet.subject(login);
        claimsSet.claim("tokenLogin", tokenLogin);
        claimsSet.claim("roles", roles);
        claimsSet.expirationTime(new Date(new Date().getTime() + 1000 * 60 * 15));
        claimsSet.notBeforeTime(new Date());
        JWSSigner jwsSigner = new MACSigner(this.llavePrivada);
        SignedJWT jwt = new SignedJWT(JWT_HEADER, claimsSet.build());
        /**
         * Se asigna la encliptacion
         */
        jwt.sign(jwsSigner);
        token = jwt.serialize();
        return token;
    }

    /**
     * Realiza la desencriptacion del token
     * @param token desencriptado
     * @return JWTClaimsSet
     * @throws ParseException
     * @throws JOSEException
     * @throws IOException
     */
    @Override
    public JWTClaimsSet desencriptorToken(String token) throws JOSEException, ParseException, IOException {
        SignedJWT jwt;
        try {
            jwt = SignedJWT.parse(this.obtenerTokenSerializado(token));
            if (jwt.verify(new MACVerifier(this.llavePrivada))) {
                return jwt.getJWTClaimsSet();
            } else {
                throw new JOSEException(EnumTokenError.ERROR_TOKEN_FIRMA.getDescripcion());
            }
        } catch (ParseException ex) {
            throw new IOException(EnumTokenError.ERROR_JWT_DECODIFICAR.getDescripcion());
        }
    }

    /**
     * Obtiene el codigo del token
     * @param token
     * @return token Serializado
     */
    @Override
    public String obtenerTokenSerializado(String token) {
        return token.split(" ")[1];
    }
}
