/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 29 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean;

import com.equifax.login.models.FDECProyecto;
import com.equifax.login.models.FDECProyectoPK;

/**
 * @author yxh24
 */
public interface FDECProyectoBean {
    /**
     * Obtiene FDECProyecto por su identificador
     * @param fdecProyectoPK
     * @return FDECProyecto
     */
    FDECProyecto obtenerFDECProyectoPorIdentificadorPK(FDECProyectoPK fdecProyectoPK);

    /**
     * Crear nuevo FDECProyecto
     * @param fdecProyecto
     * @return Mensaje confirmacion
     */
    String crearFDECProyecto(FDECProyecto fdecProyecto);

    /**
     * Modificar FDECProyecto
     * @param fdecProyecto
     * @return Mensaje confirmacion
     */
    String modificarFDECProyecto(FDECProyecto fdecProyecto);
}
