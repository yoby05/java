/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.dao.impl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.login.dao.FDECProyectoDao;
import com.equifax.login.models.FDECProyecto;
import com.equifax.login.models.FDECProyectoPK;

/**
 * @author yxh24
 */
@Stateless
public class FDECProyectoDaoImpl extends GenericDaoImpl<FDECProyecto, Long> implements FDECProyectoDao {
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    /**
     * Constructor de la clase
     */
    public FDECProyectoDaoImpl() {
        super(FDECProyecto.class);
    }

    /**
     * @param em Interfaz usada para interactuar en el contexto de la persistencia
     */
    public FDECProyectoDaoImpl(EntityManager em) {
        super(FDECProyecto.class);
        this.em = em;
    }

    /**
     * Obtiene FDECProyecto por su identificador
     * @param fdecProyectoPK
     * @return FDECProyecto
     */
    @Override
    public FDECProyecto obtenerFDECProyectoPorIdentificadorPK(FDECProyectoPK fdecProyectoPK) {
        FDECProyecto fdecProyecto = new FDECProyecto();
        try {
            fdecProyecto = this.obtenerPorCodigo(fdecProyectoPK);
        } catch (Exception e) {
            this.LOGGER.error("ERROR OBTENIENDO INFORMACION DE LA FDEC PROYECTO POR SU IDENTIFICADOR", e);
        }
        return fdecProyecto;
    }

    /**
     * Crear FDECProyecto
     * @param fdecProyecto
     * @return Mensaje de creado
     */
    @Override
    public String crearFDECProyecto(FDECProyecto fdecProyecto) {
        String resultadoMensaje = "ERROR AL CREAR EL FDEC PROYECTO";
        try {
            this.crear(fdecProyecto);
            resultadoMensaje = "FDEC PROYECTO CREADO";
        } catch (Exception e) {
            this.LOGGER.error(resultadoMensaje, e);
        }
        return resultadoMensaje;
    }

    /**
     * Modificar FDECProyecto
     * @param fdecProyecto
     * @return Mensaje de modificacion
     */
    @Override
    public String modificarFDECProyecto(FDECProyecto fdecProyecto) {
        String resultadoMensaje = "ERROR AL MODIFICAR FDEC PROYECTO POR SU IDENTIFICADOR";
        try {
            FDECProyectoPK fdecProyectoPK = fdecProyecto.getId();
            String estadoProyecto = fdecProyecto.getEstadoProyecto();
            FDECProyecto fdecProyectoEncontrado = this.obtenerFDECProyectoPorIdentificadorPK(fdecProyectoPK);
            fdecProyectoEncontrado.setEstadoProyecto(estadoProyecto);
            this.modificar(fdecProyectoEncontrado);
            resultadoMensaje = "FDEC PROYECTO MODIFICADO";
        } catch (Exception e) {
            this.LOGGER.error(resultadoMensaje, e);
        }
        return resultadoMensaje;
    }
}
