/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 27 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.enumeradores;

import java.io.Serializable;

/**
 * @author yxh24
 * @version $Revision: $
 */
public enum EnumTokenError implements Serializable {
    /**
     * Enum para error en la firma del token
     */
    ERROR_TOKEN_FIRMA("La firma del toquen no es correcta"),
    /**
     * Enum El token no tiene una estructura correcta
     */
    ERROR_TOKEN_INCORRECTO("El toquen no es correcto"),
    /**
     * Enum Error para decodificar el JWT
     */
    ERROR_JWT_DECODIFICAR("Error al decodificar el JWT"),
    /**
     * Enum La fecha de vida del token ha expirado
     */
    ERROR_TOKEN_EXPIRADO("La fecha de caducidad del token ha expirado"),
    /**
     * Enum La estructura del token es incorrecta
     */
    ERROR_TOKEN_ESTRUCTURA("El token esta vacio y/o Authorization es null y/o Estructura incorrecta");
    private String descripcion;

    /**
     * Crea una nueva instancia de la clase EnumTokenError
     * @param descripcion
     */
    private EnumTokenError(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene el atributo de clase: "descripcion"
     * @return el/la descripcion
     */
    public String getDescripcion() {
        return this.descripcion;
    }
}
