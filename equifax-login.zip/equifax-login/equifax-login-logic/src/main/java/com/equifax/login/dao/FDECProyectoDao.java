/*
 * Equifax Ecuador C.A. Sistema: Fast Decision Creado: 7 sep. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.dao;

import com.equifax.login.models.FDECProyecto;
import com.equifax.login.models.FDECProyectoPK;

/**
 * @author yxh24
 * @version $Revision: $
 */
public interface FDECProyectoDao {
    /**
     * Obtiene FDECProyecto por su identificador
     * @param fdecProyectoPK
     * @return FDECProyecto
     */
    FDECProyecto obtenerFDECProyectoPorIdentificadorPK(FDECProyectoPK fdecProyectoPK);

    /**
     * Modificar FDECProyecto
     * @param fdecProyecto
     * @return Mensaje de modificacion
     */
    String modificarFDECProyecto(FDECProyecto fdecProyecto);

    /**
     * Crear FDECProyecto
     * @param fdecProyecto
     * @return Mensaje de creado
     */
    String crearFDECProyecto(FDECProyecto fdecProyecto);
}
