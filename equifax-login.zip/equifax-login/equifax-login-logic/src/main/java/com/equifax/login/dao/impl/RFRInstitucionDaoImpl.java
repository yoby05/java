/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.login.dao.RFRInstitucionDao;
import com.equifax.login.models.RFRInstitucion;
import com.equifax.login.models.RFRInstitucionPK;
import com.equifax.login.utiles.ConstantesUtil;
import com.equifax.login.utiles.ValidacionUtil;

/**
 * @author yxh24
 */
@Stateless
public class RFRInstitucionDaoImpl extends GenericDaoImpl<RFRInstitucion, Long> implements RFRInstitucionDao {
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    /**
     * Constructor de la clase
     */
    public RFRInstitucionDaoImpl() {
        super(RFRInstitucion.class);
    }

    /**
     * @param em Interfaz usada para interactuar en el contexto de la persistencia
     */
    public RFRInstitucionDaoImpl(EntityManager em) {
        super(RFRInstitucion.class);
        this.em = em;
    }

    /**
     * Permite Obtener RFRInstitucion por Identificador
     * @param identificadorInstitucion Identificador PK de RFRInstitucion
     * @return RFRInstitucion
     */
    @Override
    public RFRInstitucion obtenerInstitucionPorIdentificadorPK(RFRInstitucionPK identificadorInstitucion) {
        RFRInstitucion rfrInstitucion = new RFRInstitucion();
        try {
            rfrInstitucion = this.obtenerPorCodigo(identificadorInstitucion);
        } catch (Exception e) {
            this.LOGGER.error("ERROR OBTENIENDO INFORMACION DE LA RFR INSTITUCION POR SU IDENTIFICADOR", e);
        }
        return rfrInstitucion;
    }

    /**
     * Obtiene todas las intituciones por nombre de su tipo
     * @param nombreTipoInstitucion Nombre del RFRInstitucion
     * @return List<RFRInstitucion>
     */
    @Override
    public List<RFRInstitucion> obtenerInstitucionesPorNombreTipo(String nombreTipoInstitucion) {
        List<RFRInstitucion> rfrInstituciones = new ArrayList<RFRInstitucion>();
        try {
            Query queryInstituciones = this.em.createNamedQuery(RFRInstitucion.OBTENER_INSTITUCION_POR_NOMBRE_TIPO)
                    .setParameter(ConstantesUtil.NOMBRE_TIPO_INSTITUCION, nombreTipoInstitucion);
            // .setParameter(ConstantesUtil.ELIMINADO, Eliminado.NO.descripcion);
            rfrInstituciones = ValidacionUtil.convertirLista(queryInstituciones);
        } catch (Exception e) {
            this.LOGGER.error("ERROR OBTENIENDO INFORMACION DE LA RFR INSTITUCION POR EL NOMBRE DE TIPO", e);
        }
        return rfrInstituciones;
    }

    /**
     * Obtiene todas las intituciones por rango de Identificadores
     * @param codigoInstituciones Identificadores de RFRInstitucion
     * @return List<RFRInstitucion>
     */
    @Override
    public List<RFRInstitucion> obtenerInstitucionesPorCodigoInstitucionesPK(List<Long> codigoInstituciones) {
        List<RFRInstitucion> rfrInstituciones = new ArrayList<RFRInstitucion>();
        try {
            Query queryInstituciones = this.em.createNamedQuery(RFRInstitucion.OBTENER_INSTITUCION_POR_IDENTIFICADORES)
                    .setParameter(ConstantesUtil.CODIGOS, codigoInstituciones);
            // .setParameter(ConstantesUtil.ELIMINADO, Eliminado.NO.descripcion);
            rfrInstituciones = ValidacionUtil.convertirLista(queryInstituciones);
        } catch (Exception e) {
            this.LOGGER.error("ERROR OBTENIENDO INFORMACION DE LA RFR INSTITUCION POR RANGO IDENTIFICADORES", e);
        }
        return rfrInstituciones;
    }

    /**
     * Permite Obtener RFRInstitucion por Identificador
     * @param identificadorInstitucion Identificador RFRInstitucion
     * @return RFRInstitucion
     */
    public RFRInstitucion obtenerInstitucionPorIdentificadorTest(Long identificadorInstitucion) {
        List<RFRInstitucion> rfrInstituciones = new ArrayList<RFRInstitucion>();
        try {
            Query queryCodigoInstitucion = this.em.createNamedQuery(RFRInstitucion.OBTENER_INSTITUCION_POR_IDENTIFICADOR)
                    .setParameter(ConstantesUtil.CODIGO_INSTITUCION, identificadorInstitucion);
            // .setParameter(ConstantesUtil.ELIMINADO, Eliminado.NO.descripcion);
            rfrInstituciones = ValidacionUtil.convertirLista(queryCodigoInstitucion);
        } catch (Exception e) {
            this.LOGGER.error("ERROR OBTENIENDO INFORMACION DE LA RFR INSTITUCION POR SU IDENTIFICADOR", e);
        }
        return rfrInstituciones.get(0);
    }
}
