'use strict';

/* Controllers */


var app = angular.module('nglogin.controllers', []);


// Clear browser cache (in development mode)
//
// http://stackoverflow.com/questions/14718826/angularjs-disable-partial-caching-on-dev-machine
app.run(function ($rootScope, $templateCache) {
    $rootScope.$on('$viewContentLoaded', function () {
        $templateCache.removeAll();
    });
});

app.controller('CtrInstitucion', ['$scope', 'InstitucionFactory', function ($scope, InstitucionFactory) {
    $scope.bla = 'bla from controller';
    InstitucionFactory.get({}, function (institucionFactory) {
    	$scope.instituciones = institucionFactory;
    })
}]);
