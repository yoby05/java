'use strict';

// Declare app level module which depends on filters, and services
angular.module('nglogin', ['nglogin.filters', 'nglogin.services', 'nglogin.directives', 'nglogin.controllers']).
config(['$routeProvider', function ($routeProvider) {
    $routeProvider.when('/view', {templateUrl: 'partials/partial.html', controller: 'CtrInstitucion'});
    $routeProvider.otherwise({redirectTo: '/view'});
}]);
        


