'use strict';
/* Services */

var services = angular.module('nglogin.services', ['ngResource']);

services.factory('InstitucionFactory', function ($resource) {
    return $resource('/login-acceso/rest/rfrInstitucion/prueba', {}, {
        query: {
            method: 'GET',
            params: {},
            isArray: false
        }
    })
});
