/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 1 ago. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.aplicacion;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;

import com.equifax.login.bean.impl.FiltroAutorizacionBeanImpl;

/**
 * @author yxh24
 * @version $Revision: $
 */
@ApplicationPath("rest")
public class AplicacionRest extends ResourceConfig {
    /**
     * Crea una nueva instancia de la clase AplicacionRest
     */
    public AplicacionRest() {
        /**
         * Paquete donde est�n nuestros servicios REST
         */
        this.packages("com.equifax.login.interfaces;com.equifax.login.aplicacion");
        this.register(FiltroAutorizacionBeanImpl.class);
    }
}
