/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 4 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.interfaces;

import java.util.Map;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.equifax.login.bean.UsuarioBean;
import com.equifax.login.models.Usuario;
import com.equifax.login.utiles.ConstantesUtil;
import com.equifax.login.utiles.RutaServiciosWebUtil;
import com.nimbusds.jose.JOSEException;

/**
 * @author yxh24
 * @version $Revision: $
 */
@Path(RutaServiciosWebUtil.RUTA_RAIZ_USUARIO)
public class UsuarioRest {
    @Inject
    private UsuarioBean usuarioBean;

    /**
     * Constructor sin parametros
     */
    public UsuarioRest() {
    }

    /**
     * Valida el usuario y genera un token para los permisos sobre la plataforma
     * @param usuario Entidad Usuario con la informacion para realizar el acceso
     * @return Token de acceso
     * @throws JOSEException
     */
    @POST
    @Path(RutaServiciosWebUtil.RUTA_LOGIN_GENERAR_TOKEN_POST)
    @Produces({ MediaType.APPLICATION_JSON + ConstantesUtil.UTF_8 })
    public Response autenticacionUsuario(Usuario usuario) throws JOSEException {
        /**
         * Codigo de validacion del usuario y password en la BD, si todo es correcto se genera el token
         */
        Map<String, Object> respuestaServicioWEbLogin = this.usuarioBean.servicioWEBLogin(usuario);
        Response respuesta = this.usuarioBean.autenticacionUsuario(respuestaServicioWEbLogin, usuario);
        return respuesta;
    }
}
