/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.interfaces;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.equifax.login.bean.FDECProyectoBean;
import com.equifax.login.models.FDECProyecto;
import com.equifax.login.models.FDECProyectoPK;
import com.equifax.login.utiles.RutaServiciosWebUtil;
import com.google.gson.Gson;

/**
 * @author yxh24
 */
@Path("fdecProyecto")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class FDECProyectoRest {
    @Inject
    private FDECProyectoBean fdecProyectoBean;

    /**
     * Constructor sin parametros
     */
    public FDECProyectoRest() {
    }

    /**
     * Obtiene RFRInstitucion por su identificador
     * @param identificador Identificador de la RFRInstitucion
     * @return RFRInstitucion
     * @throws ParseException
     */
    @POST
    @RolesAllowed({ "ADMIN" })
    @Path(RutaServiciosWebUtil.RUTA_CONSULTAR_POR_IDENTIFICADOR)
    public Object consultarPorIdentificador(FDECProyecto identificador) throws ParseException {
        Gson gson = new Gson();
        // RFRInstitucionPK idPK = (gson.fromJson(objetoEntrada, RFRInstitucion.class)).getId();
        FDECProyectoPK idPK = identificador.getId();
        FDECProyecto resultado = this.fdecProyectoBean.obtenerFDECProyectoPorIdentificadorPK(idPK);
        // List<FDECModelo> listaModelos = resultado.getFdecReporte().getTiposModelos();
        // for (FDECModelo fdecModelo : listaModelos) {
        // fdecModelo.setModeloReporte(null);
        // }
        // resultado.getFdecReporte().setTiposModelos(listaModelos);
        return gson.toJson(resultado);
    }

    /**
     * Crear nuevo FDECProyecto
     * @param fdecProyecto
     * @return Mensaje confirmacion
     */
    @POST
    // @RolesAllowed({ "ADMIN" })
    @Path("crearFDECProyecto")
    public Object crearFDECProyecto(FDECProyecto fdecProyecto) {
        Gson gson = new Gson();
        String mensaje = this.fdecProyectoBean.crearFDECProyecto(fdecProyecto);
        Map<String, String> mapaRespuesta = new HashMap<String, String>();
        mapaRespuesta.put("mensaje", mensaje);
        return gson.toJson(mapaRespuesta);
    }

    /**
     * Modificar FDECProyecto
     * @param fdecProyecto
     * @return Mensaje confirmacion
     */
    @POST
    // @RolesAllowed({ "ADMIN" })
    @Path("modificarFDECProyecto")
    public Object modificarFDECProyecto(FDECProyecto fdecProyecto) {
        Gson gson = new Gson();
        String mensaje = this.fdecProyectoBean.modificarFDECProyecto(fdecProyecto);
        Map<String, String> mapaRespuesta = new HashMap<String, String>();
        mapaRespuesta.put("mensaje", mensaje);
        return gson.toJson(mapaRespuesta);
    }
}
