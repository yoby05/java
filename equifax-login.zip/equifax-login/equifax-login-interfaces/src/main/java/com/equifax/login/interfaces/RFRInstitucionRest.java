/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.interfaces;

import java.text.ParseException;
import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.equifax.login.bean.RFRInstitucionBean;
import com.equifax.login.models.RFRInstitucion;
import com.equifax.login.models.RFRInstitucionPK;
import com.equifax.login.utiles.RutaServiciosWebUtil;
import com.google.gson.Gson;

/**
 * @author yxh24
 */
@Path(RutaServiciosWebUtil.RUTA_RAIZ_INSTITUCION)
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class RFRInstitucionRest {
    @Inject
    private RFRInstitucionBean rfrInstitucionBean;

    /**
     * Constructor sin parametros
     */
    public RFRInstitucionRest() {
    }

    /**
     * Obtiene RFRInstitucion por su identificador
     * @param identificador Identificador de la RFRInstitucion
     * @return RFRInstitucion
     * @throws ParseException
     */
    @POST
    @RolesAllowed({ "ADMIN" })
    @Path(RutaServiciosWebUtil.RUTA_CONSULTAR_POR_IDENTIFICADOR)
    public Object consultarPorIdentificador(RFRInstitucion identificador) throws ParseException {
        Gson gson = new Gson();
        // RFRInstitucionPK idPK = (gson.fromJson(objetoEntrada, RFRInstitucion.class)).getId();
        RFRInstitucionPK idPK = identificador.getId();
        RFRInstitucion resultado = this.rfrInstitucionBean.obtenerInstitucionPorIdentificadorPK(idPK);
        return gson.toJson(resultado);
    }

    /**
     * @return
     */
    @GET
    @Path("prueba")
    public Object prueba() {
        Gson gson = new Gson();
        RFRInstitucionPK institucionPK = new RFRInstitucionPK();
        institucionPK.setCodigoInstitucion(5077L);
        RFRInstitucionPK idPK = institucionPK;
        RFRInstitucion resultado = this.rfrInstitucionBean.obtenerInstitucionPorIdentificadorPK(idPK);
        return gson.toJson(resultado);
    }

    /**
     * Obtiene List<RFRInstitucion> por sus identificadores
     * @param identificadores Lista con los identificadores de RFRInstitucion
     * @return List<RFRInstitucion>
     * @throws ParseException
     */
    @POST
    @RolesAllowed({ "ADMIN" })
    @Path(RutaServiciosWebUtil.RUTA_CONSULTAR_POR_IDENTIFICADORES)
    public Object consultarPorIdentificadores(List<RFRInstitucion> identificadores) throws ParseException {
        Gson gson = new Gson();
        // RFRInstitucion[] arregloRFRInstituciones = gson.fromJson(objetoEntrada.toString(), RFRInstitucion[].class);
        // List<RFRInstitucion> institucionesTransformado = Arrays.asList(arregloRFRInstituciones);
        List<RFRInstitucion> rfrInstituciones =
                this.rfrInstitucionBean.obtenerInstitucionesPorCodigoInstitucionesPK(identificadores);
        return gson.toJson(rfrInstituciones);
    }

    /**
     * Obtiene RFRInstitucion por su identificador
     * @param id Identificador del RFRInstitucion
     * @return RFRInstitucion
     * @throws ParseException
     */
    @GET
    @RolesAllowed({ "QA" })
    @Path(RutaServiciosWebUtil.RUTA_CONSULTAR_POR_IDENTIFICADOR_GET)
    public Object consultarPorIdentificadorGet(@PathParam("id") Long id) throws ParseException {
        Gson gson = new Gson();
        RFRInstitucionPK rfrInstitucionPK = new RFRInstitucionPK(id);
        RFRInstitucion rfrInstitucion = this.rfrInstitucionBean.obtenerInstitucionPorIdentificadorPK(rfrInstitucionPK);
        return gson.toJson(rfrInstitucion);
    }

    /**
     * Obtiene todas las intituciones por nombre del tipo de la RFRInstitucion
     * @param nombreTipoRFRInstitucion Nombre del tipo de la RFRInstitucion
     * @return List<RFRInstitucion>
     * @throws ParseException
     */
    @POST
    @RolesAllowed({ "ADMIN" })
    @Path(RutaServiciosWebUtil.RUTA_CONSULTAR_POR_NOMBRE_TIPO_POST)
    public Object consultarPorNombreTipoInstitucionGet(RFRInstitucion nombreTipoRFRInstitucion) throws ParseException {
        Gson gson = new Gson();
        List<RFRInstitucion> rfrInstituciones =
                this.rfrInstitucionBean.obtenerInstitucionesPorNombreTipo(nombreTipoRFRInstitucion);
        return gson.toJson(rfrInstituciones);
    }
}
