/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 23 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.client.exepciones;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.ejb.ApplicationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author yxh24
 * @version $Revision: $
 */
@ApplicationException(rollback = true, inherited = true)
@JsonIgnoreProperties({ "stackTrace", "cause" })
public class BaseExcepcion extends RuntimeException {
    private static final long serialVersionUID = 7805393878607788241L;
    private static final Logger logger = LoggerFactory.getLogger(BaseExcepcion.class);
    protected String id;
    protected String error;
    protected String codigo;

    /*
     * Varios Consturctores
     */
    /**
     * Crea una nueva instancia de la clase BaseExcepcion
     */
    public BaseExcepcion() {
    }

    /**
     * Agrega un mensaje de error
     */
    private final void agregarMensajeError() {
        String mensajeError = null;
        try {
            ResourceBundle resourceBundle = ResourceBundle.getBundle("/messages");
            if (resourceBundle != null) {
                mensajeError = resourceBundle.getString(this.codigo);
            }
        } catch (MissingResourceException e) {
            logger.warn("NO SE PUEDE OBTENER ARCHIVO BUNDLE DE MENSAJES PARAMETRIZADOS:", e.getMessage());
        }
        if (mensajeError != null) {
            this.error = mensajeError;
        }
    }

    /**
     * @return
     */
    public String getError() {
        return this.error;
    }

    /**
     * @param error
     */
    public void setError(String error) {
        this.error = error;
    }

    /**
     * @return
     */
    public String getCodigo() {
        return this.codigo;
    }

    /**
     * @param code
     */
    public void setCodigo(String code) {
        this.codigo = code;
        this.agregarMensajeError();
    }

    /**
     * @return
     */
    public String getId() {
        return this.id;
    }

    /**
     * @param id
     */
    public void setId(String id) {
        this.id = id;
    }
}
