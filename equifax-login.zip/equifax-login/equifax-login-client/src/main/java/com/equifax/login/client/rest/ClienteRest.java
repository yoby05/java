/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 23 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.client.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.equifax.login.client.exepciones.BaseExcepcion;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class ClienteRest {
    protected Client cliente;
    protected WebTarget identificadorRecurso;
    protected static final String TIPO_MEDIO = MediaType.APPLICATION_JSON;

    /**
     * Constructor sin parametros
     */
    public ClienteRest() {
    }

    /**
     * Permite abrir conexion de cliente
     * @param direccionServicio Direccion para consumir el servicio
     */
    public void abrirConexionCliente(String direccionServicio) {
        this.cliente = ClientBuilder.newClient();
        this.identificadorRecurso = this.cliente.target(direccionServicio);
    }

    /**
     * Metodo que lanza Excepcion
     * @param codigoRespuestaHTTP codigo de error
     * @param respuestaHTTP mensaje de error
     */
    protected void lanzarExcepcionBase(int codigoRespuestaHTTP, String respuestaHTTP) {
        BaseExcepcion baseExcepcion = new BaseExcepcion();
        baseExcepcion.setCodigo(String.valueOf(codigoRespuestaHTTP));
        baseExcepcion.setError(respuestaHTTP);
        throw baseExcepcion;
    }

    /**
     * Verifica la Respuesta de la peticion REST
     * @param respuestaServicio Respuesta del servicio
     */
    public void verificaRespuestaPeticionRest(Response respuestaServicio) {
        String respuestaHTTP = respuestaServicio.getStatusInfo().getReasonPhrase();
        int codigoRespuestaHTTP = respuestaServicio.getStatusInfo().getStatusCode();
        Response.Status.Family tipoRespuestaHTTP = respuestaServicio.getStatusInfo().getFamily();
        if (Response.Status.Family.SUCCESSFUL != tipoRespuestaHTTP) {
            this.lanzarExcepcionBase(codigoRespuestaHTTP, respuestaHTTP);
        }
    }
}
