/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 23 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.client.rest;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.ejb.Stateless;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

/**
 * @author yxh24
 * @version $Revision: $
 */
@Stateless
public class LoginClienteRest extends ClienteRest {
    /**
     * Crea una nueva instancia de la clase LoginClienteRest
     */
    public LoginClienteRest() {
    }

    /**
     * Permite consumir el servicio de Configuracion Documento
     * @param nombreUsuario
     * @param passUsuario
     * @param direccionServicio Direccion para consumir el servicio
     * @return List<Map<String, Object>>
     */
    public Map<String, Object> obtenerLogin(String nombreUsuario, String passUsuario, String direccionServicio) {
        this.abrirConexionCliente(direccionServicio);
        Response respuestaLogin = this.identificadorRecurso.request(TIPO_MEDIO)
                .post(Entity.json(this.construirTramaRestConfiguracionDocumento(nombreUsuario, passUsuario)));
        this.verificaRespuestaPeticionRest(respuestaLogin);
        Map<String, Object> tramaRespuestaLogin = respuestaLogin.readEntity(new GenericType<Map<String, Object>>() {
        });
        return tramaRespuestaLogin;
    }

    /**
     * Construye la trama a enviar.
     * @param tipoDocumento Tipo de documento
     * @return TramaRestBase<Map<String, Object>>
     */
    private String construirTramaRestConfiguracionDocumento(String nombreUsuario, String passUsuario) {
        Gson gson = new Gson();
        Map<String, String> mapaLogin = new LinkedHashMap<String, String>();
        mapaLogin.put("user", nombreUsuario);
        mapaLogin.put("pass", passUsuario);
        return gson.toJson(mapaLogin, LinkedHashMap.class);
    }
}
