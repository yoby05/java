#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package ${package}.interfaces;

import java.text.ParseException;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import ${package}.bean.RFRInstitucionBean;
import ${package}.models.RFRInstitucion;
import ${package}.models.RFRInstitucionPK;
import ${package}.tools.ConstantesUtil;
import com.google.gson.Gson;

/**
 * @author yxh24
 */
@Path(ConstantesUtil.RUTA_RAIZ_INSTITUCION)
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class RFRInstitucionRest {
    @Inject
    private RFRInstitucionBean rfrInstitucionBean;

    /**
     * Constructor sin parametros
     */
    public RFRInstitucionRest() {
    }

    /**
     * Obtiene informaci�n de la Instituci�n por su identificaci�n
     * @param objetoEntrada objeto con la trama de entrada
     * @return RFRInstitucion
     * @throws ParseException
     */
    @POST
    @Path(ConstantesUtil.RUTA_CONSULTAR_POR_IDENTIFICADOR)
    public Object consultarPorIdentificador(Object objetoEntrada) throws ParseException {
        Gson gson = new Gson();
        RFRInstitucionPK idPK = (gson.fromJson(objetoEntrada.toString(), RFRInstitucion.class)).getId();
        RFRInstitucion rfrInstitucion = rfrInstitucionBean.obtenerInstitucionPorIdentificadorPK(idPK);
        return gson.toJson(rfrInstitucion);
    }

    /**
     * Obtiene informaci�n de la Instituci�n por su identificaci�n
     * @param id C�digo de la instituci�n
     * @return RFRInstitucion
     * @throws ParseException
     */
    @GET
    @Path(ConstantesUtil.RUTA_CONSULTAR_POR_IDENTIFICADOR_GET)
    public Object consultarPorIdentificadorGet(@PathParam("id") Long id) throws ParseException {
        Gson gson = new Gson();
        RFRInstitucionPK rfrInstitucionPK = new RFRInstitucionPK(id);
        RFRInstitucion rfrInstitucion = rfrInstitucionBean.obtenerInstitucionPorIdentificadorPK(rfrInstitucionPK);
        return gson.toJson(rfrInstitucion);
    }

    /**
     * Obtiene todas las intituciones por nombre del tipo de instituci�n
     * @param objetoEntrada objeto con la trama de entrada
     * @return List<RFRInstitucion>
     * @throws ParseException
     */
    @POST
    @Path(ConstantesUtil.RUTA_CONSULTAR_POR_NOMBRE_TIPO_POST)
    public Object consultarPorNombreTipoInstitucionGet(Object objetoEntrada) throws ParseException {
        Gson gson = new Gson();
        RFRInstitucion rfrInstitucion = gson.fromJson(objetoEntrada.toString(), RFRInstitucion.class);
        List<RFRInstitucion> rfrInstituciones = rfrInstitucionBean.obtenerInstitucionesPorNombreTipo(rfrInstitucion);
        return gson.toJson(rfrInstituciones);
    }
}
