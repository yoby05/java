#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/*
 * Equifax Ecuador C.A.
 * Sistema: COLLECTOR EC
 * Creado:  26 jul. 2018 
 * 
 * Los contenidos de este archivo son propiedad intelectual de Equifax Ecuador C.A.
 * 
 * Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package ${package}.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import ${package}.tools.SecuenciaAutomatica;

/**
 * The primary key class for the CARGA database table.
 */
@Embeddable
public class RFRInstitucionPK implements Serializable {
    // default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;
    @Column(name = "COD_INSTITUCION")
    @SecuenciaAutomatica
    private Long codigoInstitucion;

    /**
     * Crea una nueva instancia de la clase CargaPK
     */
    public RFRInstitucionPK() {
    }

    /**
     * Crea una nueva instancia de la clase RFRInstitucionPK
     * @param codigoInstitucion
     */
    public RFRInstitucionPK(Long codigoInstitucion) {
        super();
        this.codigoInstitucion = codigoInstitucion;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RFRInstitucionPK)) {
            return false;
        }
        RFRInstitucionPK castOther = (RFRInstitucionPK) other;
        return (codigoInstitucion == castOther.codigoInstitucion);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int hash = 17;
        if (codigoInstitucion != null) {
            hash = hash * prime + ((int) (codigoInstitucion ^ (codigoInstitucion >>> 32)));
        }
        return hash;
    }
}