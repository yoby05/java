#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package ${package}.dao.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import ${package}.dao.RFRInstitucionDao;
// import ${package}.enumeration.Eliminado;
import ${package}.models.RFRInstitucion;
import ${package}.models.RFRInstitucionPK;
import ${package}.tools.ConstantesUtil;
import ${package}.tools.ValidacionUtil;

/**
 * @author yxh24
 */
@Stateless
public class RFRInstitucionDaoImpl extends GenericDaoImpl<RFRInstitucion, Long> implements RFRInstitucionDao {
    /**
     * Constructor de la clase
     */
    public RFRInstitucionDaoImpl() {
        super(RFRInstitucion.class);
    }

    /**
     * @param em Interfaz usada para interactuar en el contexto de la persistencia
     */
    public RFRInstitucionDaoImpl(EntityManager em) {
        super(RFRInstitucion.class);
        this.em = em;
    }

    /**
     * Permite Obtener informaci�n de una Instituci�n por Identificador
     * @param identificadorInstitucion Identificador de la Constituci�n
     * @return RFRInstitucion
     */
    @Override
    public RFRInstitucion obtenerInstitucionPorIdentificador(RFRInstitucionPK identificadorInstitucion) {
        return obtenerPorCodigo(identificadorInstitucion);
    }

    /**
     * Obtiene todas las intituciones por su nombre
     * @param nombreTipoInstitucion Nombre del tipo de la instituci�n
     * @return List<RFRInstitucion>
     */
    @Override
    public List<RFRInstitucion> obtenerInstitucionesPorNombreTipo(String nombreTipoInstitucion) {
        Query queryInstituciones = em.createNamedQuery(RFRInstitucion.OBTENER_INSTITUCION_POR_NOMBRE_TIPO)
                .setParameter(ConstantesUtil.NOMBRE_TIPO_INSTITUCION, nombreTipoInstitucion);
        // .setParameter(ConstantesUtil.ELIMINADO, Eliminado.NO.descripcion);
        List<RFRInstitucion> rfrInstituciones = ValidacionUtil.convertirLista(queryInstituciones);
        return rfrInstituciones;
    }

    /**
     * Permite Obtener informaci�n de una Instituci�n por Identificador
     * @param identificadorInstitucion Identificador de la Constituci�n
     * @return RFRInstitucion
     */
    public RFRInstitucion obtenerInstitucionPorIdentificadorTest(Long identificadorInstitucion) {
        Query queryCodigoInstitucion = em.createNamedQuery(RFRInstitucion.OBTENER_INSTITUCION_POR_IDENTIFICADOR)
                .setParameter(ConstantesUtil.CODIGO_INSTITUCION, identificadorInstitucion);
        // .setParameter(ConstantesUtil.ELIMINADO, Eliminado.NO.descripcion);
        return (RFRInstitucion) queryCodigoInstitucion.getSingleResult();
    }
}
