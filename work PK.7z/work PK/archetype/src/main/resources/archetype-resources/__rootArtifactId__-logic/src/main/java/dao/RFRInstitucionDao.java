#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package ${package}.dao;

import java.util.List;

import ${package}.models.RFRInstitucion;
import ${package}.models.RFRInstitucionPK;

/**
 * @author yxh24
 * @version ${symbol_dollar}Revision: ${symbol_dollar}
 */
public interface RFRInstitucionDao {
    /**
     * Permite Obtener informaci�n de una Instituci�n por Identificador
     * @param identificadorInstitucion Identificador de la Constituci�n
     * @return RFRInstitucion
     */
    RFRInstitucion obtenerInstitucionPorIdentificador(RFRInstitucionPK identificadorInstitucion);

    /**
     * Obtiene todas las intituciones por su nombre del tipo
     * @param nombreTipoInstitucion Nombre del tipo de la instituci�n
     * @return List<RFRInstitucion>
     */
    List<RFRInstitucion> obtenerInstitucionesPorNombreTipo(String nombreTipoInstitucion);
}
