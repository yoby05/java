#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package ${package}.tools;

/**
 * @author yxh24
 * @version ${symbol_dollar}Revision: ${symbol_dollar}
 */
public final class ConstantesUtil {
    /**
     * Para castear el objeto de una lista
     */
    public static final String UNCHECKED = "unchecked";
    /**
     * Variable para identificar eliminado l�gico
     */
    public static final String ELIMINADO = "eliminado";
    /**
     * Transformar Fecha
     */
    public static final String STRING_FORMATO_GMT_FECHA_DIA_MES_ANIO = "dd/MM/yyyy";
    /**
     * C�digo del usuario
     */
    public static final String CODIGO_USUARIO = "codigoUsuario";
    /**
     * C�digo de la instituci�n
     */
    public static final String CODIGO_INSTITUCION = "codigoInstitucion";
    /**
     * Nombre de la Instituci�n
     */
    public static final String NOMBRE_TIPO_INSTITUCION = "nombreTipoInstitucion";
}
