#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package ${package}.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

/**
 * Implementaci�n del patr�n de acceso a datos con m�todos gen�ricos CRUD
 * @author yxh24
 * @param <T>
 * @param <I>
 */
public class GenericDaoImpl<T, I extends Serializable> {
    @Inject
    protected EntityManager em;
    private final Class<T> tablaEntidad;

    /**
     * Constructor
     * @param tablaEntidad
     */
    public GenericDaoImpl(final Class<T> tablaEntidad) {
        this.tablaEntidad = tablaEntidad;
    }

    /**
     * M�todo gen�rico para insertar un registro
     * @param tablaEntidad tabla de tipo entidad
     */
    public void crear(final T tablaEntidad) {
        this.em.persist(tablaEntidad);
    }

    /**
     * M�todo gen�rico para actualizar un registro
     * @param tablaEntidad tabla de tipo entidad
     * @return tabla de tipo entidad con registro modificado
     */
    public T modificar(final T tablaEntidad) {
        return this.em.merge(tablaEntidad);
    }

    /**
     * M�todo gen�rico para buscar un registro correspondiente a su identificador principal
     * @param identificador
     * @return tabla de tipo entidad
     */
    public T obtenerPorCodigo(Object identificador) {
        return this.em.find(this.tablaEntidad, identificador);
    }

    /**
     * M�todo gen�rico para obtener todos los registros
     * @return lista de registros correspondiente a la tabla de tipo entidad
     */
    public List<T> obtenerTodos() {
        TypedQuery<T> consulta =
                this.em.createQuery("Select t from " + this.tablaEntidad.getSimpleName() + " t", this.tablaEntidad);
        return consulta.getResultList();
    }

    /**
     * M�todo gen�rico para obtener todos los registros paginados
     * @param numeroDePagina n�mero de la p�gina
     * @param elementosPorPagina tama�o o elementos de la pag�na
     * @return lista de registros correspondiente a la tabla de tipo entidiad agrupados en p�ginas
     */
    public List<T> obtenerTodos(int numeroDePagina, int elementosPorPagina) {
        TypedQuery<T> consulta =
                this.em.createQuery("Select t from " + this.tablaEntidad.getSimpleName() + " t", this.tablaEntidad);
        consulta.setFirstResult((numeroDePagina - 1) * elementosPorPagina);
        consulta.setMaxResults(elementosPorPagina);
        return consulta.getResultList();
    }
}
