#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/*
 * Equifax Ecuador C.A.
 * Sistema: COLLECTOR EC
 * Creado:  25 jul. 2018 
 * 
 * Los contenidos de este archivo son propiedad intelectual de Equifax Ecuador C.A.
 * 
 * Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package ${package}.tools;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

/**
 * @author yxh24
 * @version ${symbol_dollar}Revision: ${symbol_dollar}
 */
public final class ValidacionUtil {
    private ValidacionUtil() {
    }

    /**
     * Metodo generico para determinar si un objecto es nulo
     * @param object es el valor de entrada
     * @return Boolean
     */
    public static Boolean esNulo(Object object) {
        return (object == null) ? true : false;
    }

    /**
     * Metodo generico para determinar si un String, Lista, etc esta vacio Se utiliza la expresi�n unchecked para poder convertir
     * Objeto en List <Object>
     * @param objeto es el valor de entrada
     * @return Boolean
     */
    @SuppressWarnings(ConstantesUtil.UNCHECKED)
    public static Boolean esVacio(Object objeto) {
        if (esNulo(objeto)) {
            return true;
        } else if (objeto instanceof String) {
            if (((String) objeto).trim().equals("")) {
                return true;
            }
        } else if (objeto instanceof String) {
            if (((String) objeto).trim().equals("0")) {
                return true;
            }
        } else if (objeto instanceof List) {
            List<Object> lista = (List<Object>) objeto;
            if (lista.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Valida si el c�digo es null o vacio retorna null, caso contrario retorna el n�mero
     * @param codigo valor de entrada
     * @return Long
     */
    public static Long valLong(Object codigo) {
        return (codigo == null || codigo.toString().trim().isEmpty()) ? null : Long.valueOf(codigo.toString());
    }

    /**
     * Valida si el c�digo es null o vacio retorna null, caso contrario retorna el n�mero
     * @param codigo valor de entrada
     * @return Long
     */
    public static Long valObjeto(Object codigo) {
        return (codigo == null || codigo.toString().equals("0") || codigo.toString().trim().isEmpty()) ? null
                : Long.valueOf(codigo.toString());
    }

    /**
     * Valida si cadena es null o vacio retorna null, caso contrario retorna el cadena
     * @param cadena valor de entrada
     * @return String
     */
    public static String valString(Object cadena) {
        return (cadena == null || cadena.toString().isEmpty()) ? null : cadena.toString();
    }

    /**
     * Valida si fecha es null o invalida retorna null, caso contrario retorna la fecha
     * @param fecha valor de entrada
     * @return Date
     */
    public static Date valDate(Object fecha) {
        if (esNulo(fecha) || "".equals(fecha.toString())) {
            return null;
        }
        Date fechaResultante = null;
        try {
            DateFormat formato = new SimpleDateFormat(ConstantesUtil.STRING_FORMATO_GMT_FECHA_DIA_MES_ANIO);
            fechaResultante = formato.parse(fecha.toString());
        } catch (ParseException e) {
            return null;
        }
        return fechaResultante;
    }

    /**
     * Aumenta un dia a la fecha
     * @param fecha valor de entrada
     * @param dias cantidad de dias
     * @return Date
     */
    public static Date sumarDias(Date fecha, int dias) {
        if (esNulo(fecha)) {
            return null;
        } else {
            Calendar calendario = Calendar.getInstance();
            calendario.setTime(fecha);
            calendario.add(Calendar.DAY_OF_YEAR, dias);
            return calendario.getTime();
        }
    }

    /**
     * Valida si un objeto tiene entrada
     * @param objeto valor de entrada
     * @return Boolean
     */
    public static Boolean contieneInformacion(Object objeto) {
        return (esNulo(objeto) || esVacio(objeto) || objeto.toString().equals("0")) ? false : true;
    }

    /**
     * Obtiene lista de cualquier objeto Se utiliza la expresi�n unchecked para poder convertir a cualquier List <T>
     * @param query Para la consulta
     * @param <T> T generica
     * @return query
     */
    @SuppressWarnings(ConstantesUtil.UNCHECKED)
    public static <T> List<T> convertirLista(Query query) {
        return query.getResultList();
    }
}
