/*
 * Equifax Ecuador C.A.
 * Sistema: COLLECTOR EC
 * Creado:  25 jul. 2018 
 * 
 * Los contenidos de este archivo son propiedad intelectual de Equifax Ecuador C.A.
 * 
 * Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.eis.tools;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Anotacion utilizada para marcar las secuencias autogeneradas en los id de las clases de las entidades
 * @author jperez
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface SecuenciaAutomatica {
}
