/*
 * Equifax Ecuador C.A.
 * Sistema: COLLECTOR EC
 * Creado:  25 jul. 2018 
 * 
 * Los contenidos de este archivo son propiedad intelectual de Equifax Ecuador C.A.
 * 
 * Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.eis.enumeration;

import java.io.Serializable;

import com.equifax.eis.tools.ConstantesUtil;

/**
 * @author yxh24
 * @version $Revision: $
 */
public enum Estado implements Serializable {
    /**
     * Constante identifica Activo
     */
    ACT(ConstantesUtil.CONDICION_ACTIVO),
    /**
     * Constante identifica Inactivo
     */
    INA(ConstantesUtil.CONDICION_INACTIVO);
    /**
     * Constante identifica descripción
     */
    public String descripcion;

    /**
     * Constructor de la enumeracion
     * @param descripcion Valor de la descripcion
     */
    private Estado(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion Descripcion a modificar
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene el valor
     * @param valor Valor de ingreso
     * @return String
     */
    public static Estado fromString(String valor) {
        return valueOf(valor);
    }
}
