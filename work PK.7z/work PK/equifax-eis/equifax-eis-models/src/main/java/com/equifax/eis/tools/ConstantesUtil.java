/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.eis.tools;

/**
 * @author yxh24
 * @version $Revision: $
 */
public final class ConstantesUtil {
    /**
     * Formato de fecha
     */
    public static final String STRING_FORMATO_GMT_FECHA_DIA_MES_ANIO = "dd/MM/yyyy";
    /**
     * Constante identifica Si
     */
    public static final String CONDICION_SI = "SI";
    /**
     * Constante identifica No
     */
    public static final String CONDICION_NO = "NO";
    /**
     * Constante identifica Activo
     */
    public static final String CONDICION_ACTIVO = "ACT";
    /**
     * Constante identificar Inactivo
     */
    public static final String CONDICION_INACTIVO = "INA";
}
