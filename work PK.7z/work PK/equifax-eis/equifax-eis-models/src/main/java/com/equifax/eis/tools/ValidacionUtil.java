/*
 * Equifax Ecuador C.A.
 * Sistema: COLLECTOR EC
 * Creado:  25 jul. 2018 
 * 
 * Los contenidos de este archivo son propiedad intelectual de Equifax Ecuador C.A.
 * 
 * Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.eis.tools;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author yxh24
 *
 */
public final class ValidacionUtil {

	private ValidacionUtil() {
	}
	
	/**
	 * Metodo generico para determinar si un objecto es nulo
	 * 
	 * @param object
	 *            es el valor de entrada
	 * @return Boolean
	 */
	public static Boolean esNulo(Object object) {
		return (object == null) ? true : false;
	}
	
	/**
	 * Valida si fecha es null o invalida retorna null, caso contrario retorna la
	 * fecha
	 * 
	 * @param fecha
	 *            valor de entrada
	 * @return Date
	 */
	public static Date valDate(Object fecha) {

		if (esNulo(fecha) || "".equals(fecha.toString())) {
			return null;
		}
		Date fechaResultante = null;
		try {
			DateFormat formato = new SimpleDateFormat(ConstantesUtil.STRING_FORMATO_GMT_FECHA_DIA_MES_ANIO);
			fechaResultante = formato.parse(fecha.toString());
		} catch (ParseException e) {
			return null;
		}

		return fechaResultante;
	}
}
