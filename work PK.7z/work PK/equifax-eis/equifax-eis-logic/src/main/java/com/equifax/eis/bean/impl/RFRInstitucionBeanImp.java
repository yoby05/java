/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 26 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.eis.bean.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.equifax.eis.bean.RFRInstitucionBean;
import com.equifax.eis.dao.RFRInstitucionDao;
import com.equifax.eis.models.RFRInstitucion;
import com.equifax.eis.models.RFRInstitucionPK;

/**
 * @author yxh24
 */
@Stateless
public class RFRInstitucionBeanImp implements RFRInstitucionBean {
    @Inject
    private RFRInstitucionDao rfrInstitucionDao;

    /**
     * Constructor sin parametros
     */
    public RFRInstitucionBeanImp() {
    }

    /**
     * Permite Obtener informaci�n de una Instituci�n por Identificador
     * @param rfrInstitucionPK
     * @return RFRInstitucion
     */
    @Override
    public RFRInstitucion obtenerInstitucionPorIdentificadorPK(RFRInstitucionPK rfrInstitucionPK) {
        return rfrInstitucionDao.obtenerInstitucionPorIdentificador(rfrInstitucionPK);
    }

    /**
     * Obtiene todas las intituciones por su nombre del tipo
     * @param rfrInstitucion Nombre del tipo de la instituci�n
     * @return List<RFRInstitucion>
     */
    @Override
    public List<RFRInstitucion> obtenerInstitucionesPorNombreTipo(RFRInstitucion rfrInstitucion) {
        String nombreTipoInstitucion = rfrInstitucion.getNombreTipoInstitucion();
        return rfrInstitucionDao.obtenerInstitucionesPorNombreTipo(nombreTipoInstitucion);
    }
}
