/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 29 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.eis.bean;

import java.util.List;

import com.equifax.eis.models.RFRInstitucion;
import com.equifax.eis.models.RFRInstitucionPK;

/**
 * @author yxh24
 */
public interface RFRInstitucionBean {
    /**
     * Permite Obtener informaci�n de una Instituci�n por Identificador
     * @param rfrInstitucionPK
     * @return RFRInstitucion
     */
    RFRInstitucion obtenerInstitucionPorIdentificadorPK(RFRInstitucionPK rfrInstitucionPK);

    /**
     * Obtiene todas las intituciones por nombre de su tipo
     * @param rfrInstitucion Entidad con el nombre de la instituci�n
     * @return List<RFRInstitucion>
     */
    List<RFRInstitucion> obtenerInstitucionesPorNombreTipo(RFRInstitucion rfrInstitucion);
}
