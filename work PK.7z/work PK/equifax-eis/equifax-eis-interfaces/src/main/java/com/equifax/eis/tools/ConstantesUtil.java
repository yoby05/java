/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.eis.tools;

/**
 * @author yxh24
 * @version $Revision: $
 */
public final class ConstantesUtil {
    /**
     * Ruta Raiz entidad RFRInstitucion
     */
    public static final String RUTA_RAIZ_INSTITUCION = "/rfrInstitucion";
    /**
     * Ruta Para consultar por identificador POST
     */
    public static final String RUTA_CONSULTAR_POR_IDENTIFICADOR = "/consultarPorIdentificador";
    /**
     * Ruta Para consultar por identificador GET
     */
    public static final String RUTA_CONSULTAR_POR_IDENTIFICADOR_GET = "/consultarPorIdentificador/{id}";
    /**
     * Ruta Para consultar por nombre del tipoPOST
     */
    public static final String RUTA_CONSULTAR_POR_NOMBRE_TIPO_POST = "/consultarPorNombreTipo";
}
