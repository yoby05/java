USE [CRUtilitarios]
BEGIN TRAN

	CREATE TABLE FDEC_Proyecto( 
	[IdProyecto] [numeric](18, 0) IDENTITY(1,1) NOT NULL,
	[Estado] [bit] NOT NULL,
	CONSTRAINT [PK_Proyecto_IdProyecto] PRIMARY KEY (IdProyecto),
	);

	CREATE TABLE FDEC_Reporte( 
	[IdReporteProyecto] [numeric](18, 0) IDENTITY(1,1) NOT NULL,
	[IdProyecto] [numeric](18, 0) UNIQUE NOT NULL,
	[IdReporte] [numeric](18, 0) NOT NULL, --DECIDA
	[Nombre] [varchar](100) NULL,
	[IdCliente] [numeric](18, 0) NULL,
	[Valida] [varchar](1) NULL,
	CONSTRAINT [PK_Reporte_IdReporteProyecto] PRIMARY KEY (IdReporteProyecto),
	CONSTRAINT [FK_Reporte_IdProyecto] FOREIGN KEY (IdProyecto) REFERENCES FDEC_Proyecto (IdProyecto)
	);

	CREATE TABLE FDEC_Producto(
	[IdProductoProyecto] [numeric](18, 0) IDENTITY(1,1) NOT NULL,
	[IdReporteProyecto] [numeric](18, 0) UNIQUE NOT NULL,
	[IdProducto] [numeric](18, 0) NOT NULL, --DECIDA
	[Canal] [varchar](100) NULL,
	[Abreviatura] [varchar](100) NULL,
	[IdProductoMK] [numeric](18, 0) NULL,
	[IdCategoria] [numeric](18, 0)  NULL,
	CONSTRAINT [PK_Producto_IdProductoProyecto] PRIMARY KEY (IdProductoProyecto),
	CONSTRAINT [FK_Producto_IdReporteProyecto] FOREIGN KEY (IdReporteProyecto) REFERENCES FDEC_Reporte (IdReporteProyecto)
	);

	CREATE TABLE FDEC_Modelo(
	[IdModeloProyecto] [numeric](18, 0) IDENTITY(1,1) NOT NULL,
	[IdReporteProyecto] [numeric](18, 0) NOT NULL, 
	[IdModelo] [numeric](18, 0) NOT NULL,--DECIDA
	[Tipo] [varchar](100) NULL,
	[Persona] [varchar](1) NULL,
	[Version] [varchar](100) NULL,
	CONSTRAINT [PK_Modelo_IdModeloProyecto] PRIMARY KEY (IdModeloProyecto),
	CONSTRAINT [FK_Modelo_IdReporteProyecto] FOREIGN KEY (IdReporteProyecto) REFERENCES FDEC_Reporte (IdReporteProyecto)
	);

--COMMIT
--ROLLBACK