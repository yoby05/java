USE [CRUtilitarios]
select 
proy.IdProyecto, proy.Estado, rep.IdCliente, rep.IdReporte, rep.Nombre, rep.Valida,
prod.IdProducto, prod.IdProductoMK, prod.IdCategoria, prod.Abreviatura, prod.Canal,
mode.IdModelo, mode.Persona, mode.Tipo
from FDEC_Proyecto proy 
inner join FDEC_Reporte rep on proy.IdProyecto = rep.IdProyecto
inner join FDEC_Producto prod on rep.IdReporteProyecto = prod.IdProductoProyecto
inner join FDEC_Modelo mode on mode.IdReporteProyecto = rep.IdReporteProyecto 