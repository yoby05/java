USE [CRUtilitarios]
BEGIN TRAN

declare
@nombreTabla VARCHAR(100) = null,
@table nvarchar(50)

declare CURSOR_TABLAS  CURSOR FOR
	Select 'FDEC_Modelo' union all
	Select 'FDEC_Producto' union all
	Select 'FDEC_Reporte' union all
	Select 'FDEC_Proyecto'
	
OPEN CURSOR_TABLAS     
	FETCH NEXT FROM CURSOR_TABLAS      
	into @nombreTabla
	while @@FETCH_STATUS =0
	BEGIN
		set @table = @nombreTabla
		select @table as nombre_tabla
		DECLARE @sql nvarchar(255)
		WHILE EXISTS(select * from INFORMATION_SCHEMA.TABLE_CONSTRAINTS where table_name = @table)
		BEGIN
			select    @sql = 'ALTER TABLE ' + @table + ' DROP CONSTRAINT ' + CONSTRAINT_NAME 
			from    INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
			where   table_name = @table
			exec    sp_executesql @sql
		END	
		FETCH NEXT FROM CURSOR_TABLAS      
		into @nombreTabla
	END 
	CLOSE CURSOR_TABLAS                          
	DEALLOCATE CURSOR_TABLAS	

DROP TABLE FDEC_Modelo
DROP TABLE FDEC_Producto
DROP TABLE FDEC_Reporte
DROP TABLE FDEC_Proyecto

--COMMIT
--ROLLBACK