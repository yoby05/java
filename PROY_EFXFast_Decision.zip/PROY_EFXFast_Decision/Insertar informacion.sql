USE [CRUtilitarios]
BEGIN TRAN

-- Tabla [FDEC_Proyecto]
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Proyecto]([Estado])VALUES(1)
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Proyecto]([Estado])VALUES(0)
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Proyecto]([Estado])VALUES(1)
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Proyecto]([Estado])VALUES(1)
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Proyecto]([Estado])VALUES(0)
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Proyecto]([Estado])VALUES(0)
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Proyecto]([Estado])VALUES(0)

-- Tabla [FDEC_Reporte]
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Reporte]([IdProyecto],[IdReporte],[Nombre],[IdCliente],[Valida])VALUES(1,1,'prueba1',11,'C')
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Reporte]([IdProyecto],[IdReporte],[Nombre],[IdCliente],[Valida])VALUES(2,2,'prueba2',12,'C')
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Reporte]([IdProyecto],[IdReporte],[Nombre],[IdCliente],[Valida])VALUES(3,3,'prueba3',13,'E')
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Reporte]([IdProyecto],[IdReporte],[Nombre],[IdCliente],[Valida])VALUES(4,4,'prueba4',14,'R')
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Reporte]([IdProyecto],[IdReporte],[Nombre],[IdCliente],[Valida])VALUES(5,5,'prueba5',15,'R')

-- Tabla [FDEC_Producto]
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Producto]([IdReporteProyecto],[IdProducto],[Canal],[Abreviatura],[IdProductoMK],[IdCategoria])VALUES(1,101,'WEB','TEST1',210,10)
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Producto]([IdReporteProyecto],[IdProducto],[Canal],[Abreviatura],[IdProductoMK],[IdCategoria])VALUES(2,102,'WEB','TEST2',220,20)
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Producto]([IdReporteProyecto],[IdProducto],[Canal],[Abreviatura],[IdProductoMK],[IdCategoria])VALUES(3,103,'WS','TEST3',230,30)
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Producto]([IdReporteProyecto],[IdProducto],[Canal],[Abreviatura],[IdProductoMK],[IdCategoria])VALUES(4,104,'WS','TEST4',240,40)
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Producto]([IdReporteProyecto],[IdProducto],[Canal],[Abreviatura],[IdProductoMK],[IdCategoria])VALUES(5,105,'WEB','TEST5',240,50)

-- Tabla [FDEC_Modelo]
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Modelo]([IdReporteProyecto],[IdModelo],[Tipo],[Persona],[Version])VALUES(1,2,'BANCARIZADO','N','1.0.1')
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Modelo]([IdReporteProyecto],[IdModelo],[Tipo],[Persona],[Version])VALUES(2,2,'NO BANCARIZADO','N','1.0.2')
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Modelo]([IdReporteProyecto],[IdModelo],[Tipo],[Persona],[Version])VALUES(3,2,'NO BANCARIZADO','N','1.0.3')
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Modelo]([IdReporteProyecto],[IdModelo],[Tipo],[Persona],[Version])VALUES(4,2,'BANCARIZADO','N','1.0.4')
INSERT INTO [CRUtilitarios].[dbo].[FDEC_Modelo]([IdReporteProyecto],[IdModelo],[Tipo],[Persona],[Version])VALUES(5,2,'JURIDICO','J','1.0.5')

select 
proy.IdProyecto, proy.Estado, rep.IdCliente, rep.IdReporte, rep.Nombre, rep.Valida,
prod.IdProducto, prod.IdProductoMK, prod.IdCategoria, prod.Abreviatura, prod.Canal,
mode.IdModelo, mode.Persona, mode.Tipo
from FDEC_Proyecto proy 
inner join FDEC_Reporte rep on proy.IdProyecto = rep.IdProyecto
inner join FDEC_Producto prod on rep.IdReporteProyecto = prod.IdProductoProyecto
inner join FDEC_Modelo mode on mode.IdReporteProyecto = rep.IdReporteProyecto 
--COMMIT
--ROLLBACK

