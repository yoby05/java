import { AngularBookStore41Page } from './app.po';

describe('angular-book-store41 App', () => {
  let page: AngularBookStore41Page;

  beforeEach(() => {
    page = new AngularBookStore41Page();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
