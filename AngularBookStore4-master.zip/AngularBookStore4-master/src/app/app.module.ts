import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { RootComponent } from './component/root/root.component';
import { BookListingComponent } from './component/book-listing/book-listing.component';
import { BookService } from 'app/service/book.service';
import { BookComponent } from './component/book/book.component';
import { BookDetailComponent } from './component/book-detail/book-detail.component';
import { NavbarComponent } from './component/navbar/navbar.component';
import { SignUpComponent } from './component/sign-up/sign-up.component';
import { SignInComponent } from './component/sign-in/sign-in.component';
import { AuthService } from 'app/service/auth.service';
import { CrudBooksComponent } from 'app/component/crud-books/crud-books.component';
import { CrudBookComponent } from 'app/component/crud-book/crud-book.component';
import { CrudUsersComponent } from 'app/component/crud-users/crud-users.component';
import { TabContainerComponent } from './component/tab-container/tab-container.component';
import { TabComponent } from './component/tab/tab.component';
import { MenuContainerComponent } from './component/menu-container/menu-container.component';
import { MenuItemComponent } from './component/menu-item/menu-item.component';
import { SubmenuComponent } from './component/submenu/submenu.component';

@NgModule({
  declarations: [
    RootComponent,
    BookListingComponent,
    BookComponent,
    BookDetailComponent,
    NavbarComponent,
    SignUpComponent,
    SignInComponent,
    CrudBooksComponent,
    CrudBookComponent,
    CrudUsersComponent,
    TabContainerComponent,
    TabComponent,
    MenuContainerComponent,
    MenuItemComponent,
    SubmenuComponent
  ],
  imports: [BrowserModule, HttpModule, AppRoutingModule, FormsModule],
  providers: [BookService, AuthService],
  bootstrap: [RootComponent]
})
export class AppModule {}
