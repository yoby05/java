import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crud-users',
  templateUrl: './crud-users.component.html',
  styleUrls: ['./crud-users.component.css']
})
export class CrudUsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
