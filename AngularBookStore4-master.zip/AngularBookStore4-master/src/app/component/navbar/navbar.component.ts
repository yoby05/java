import { Component, OnInit } from '@angular/core';
import { Menu } from "app/model/menu";
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  menu: Menu = {};

  constructor(private http: Http) { }

  ngOnInit() {
    this.http.get('/assets/json/menu.json')
      .toPromise()
      .then(res => res.json())
      .then(menu => this.menu = menu);
  }

}
