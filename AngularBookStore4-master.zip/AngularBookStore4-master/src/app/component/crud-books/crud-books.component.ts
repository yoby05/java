import { Component, OnInit } from '@angular/core';
import { BookService } from 'app/service/book.service';
import { Book } from 'app/model/book';

@Component({
  selector: 'app-crud-books',
  templateUrl: './crud-books.component.html',
  styleUrls: ['./crud-books.component.css']
})
export class CrudBooksComponent implements OnInit {

  books: Book[] = [];

  constructor(private bookService: BookService) { }

  ngOnInit() {
    this.bookService.getBooks().then(books => this.books = books)
  }

}
