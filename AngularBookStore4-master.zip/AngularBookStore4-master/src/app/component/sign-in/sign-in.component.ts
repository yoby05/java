import { Component, OnInit } from '@angular/core';
import { AuthService } from 'app/service/auth.service';
import { User } from 'app/model/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {

  user: User = {};

  message: string = '';

  constructor(
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit() {
  }

  signIn(form) {
    if (form.valid) {
      this.authService.signIn(this.user)
        .then(this.redirectToHome.bind(this))
        .catch(this.handleError.bind(this));
    }
  }

  private redirectToHome() {
    this.router.navigate(['/home']);
  }

  private handleError(msg) {
    this.message = msg.error.message;
  }
}
