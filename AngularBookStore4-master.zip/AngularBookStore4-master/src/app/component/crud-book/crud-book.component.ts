import { Component, OnInit } from '@angular/core';
import { Book } from 'app/model/book';
import { BookService } from 'app/service/book.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-crud-book',
  templateUrl: './crud-book.component.html',
  styleUrls: ['./crud-book.component.css']
})
export class CrudBookComponent implements OnInit {

  bookId: number = null;
  book: Book = {};

  constructor(
    private bookService: BookService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.route.params.subscribe(params => this.loadBook(params.bookId));
  }

  loadBook(bookId) {
    if (bookId) {
      this.bookId = bookId;
      this.bookService.getBook(bookId)
        .then(book => this.book = book);
    }
  }

  saveBook() {
    this.bookService.createBook(this.book)
      .then(this.redirectToBooks.bind(this));
  }

  redirectToBooks() {
    this.router.navigate(['/books']);
  }

}
