import { Component, OnInit } from '@angular/core';
import { User } from 'app/model/user';
import { AuthService } from 'app/service/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  user: User = {};
  message: string = '';

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {}

  signUp(form) {
    if (form.valid) {
      this.authService.signUp(this.user)
        .then(this.redirectToSignIn.bind(this));
        //.then(() => this.redirectToSignIn());
    }
  }

  private redirectToSignIn() {
    this.router.navigate(['/sign-in']);
  }
}
