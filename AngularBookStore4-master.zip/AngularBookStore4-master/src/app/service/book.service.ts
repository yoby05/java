import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { Book } from 'app/model/book';

const URL = 'https://lit-citadel-36705.herokuapp.com/api/Books';

@Injectable()
export class BookService {
  constructor(private http: Http) {}

  getBooks(): Promise<Book[]> {
    return this.http.get(URL)
      .toPromise()
      .then(res => res.json());
  }

  getBook(bookId): Promise<Book> {
    return this.http.get(`${URL}/${bookId}`)
      .toPromise()
      .then(res => res.json())
      .then(book => {
        book.publishedDate = new Date(book.publishedDate);
        return book;
      });
  }

  createBook(book): Promise<Book> {
    return this.http.post(URL, book)
      .toPromise()
      .then(res => res.json());
  }
}
