import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { User } from 'app/model/user';
import { Token } from 'app/model/token';

const URL = 'https://lit-citadel-36705.herokuapp.com/api/AppUsers';
const LOGIN_URL = `${URL}/login`;

@Injectable()
export class AuthService {

  constructor(private http: Http) { }

  signUp(user): Promise<User> {
    return this.http.post(URL, user)
      .toPromise()
      .then(res => res.json());
  }

  signIn(user): Promise<Token> {
    return this.http.post(LOGIN_URL, user)
      .toPromise()
      .then(res => res.json())
      .catch(error => {
        const msg = error.json();
        return Promise.reject(msg);
      });
  }
}
