import { Submenu } from 'app/model/submenu';

export class Menu {
  homeUrl?: string;
  homeLabel?: string;
  submenus?: Submenu[] = [];
}
