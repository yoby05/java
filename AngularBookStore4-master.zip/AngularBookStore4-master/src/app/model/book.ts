export interface Book {
  id?: number;
  title?: string;
  author?: string;
  price?: number;
  publishedDate?: Date;
  image?: string;
  description?: string;
}
