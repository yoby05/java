export class Token {
  id?: string;
  ttl?: number;
  userId?: number;
}
