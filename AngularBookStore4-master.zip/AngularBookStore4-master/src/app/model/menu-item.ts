export class MenuItem {
  url?:string;
  label?:string;
  active?:boolean;
}
