import { MenuItem } from 'app/model/menu-item';

export class Submenu {
  position?: string;
  items?: MenuItem[] = [];
}
