import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookListingComponent } from 'app/component/book-listing/book-listing.component';
import { SignUpComponent } from 'app/component/sign-up/sign-up.component';
import { SignInComponent } from 'app/component/sign-in/sign-in.component';
import { CrudUsersComponent } from 'app/component/crud-users/crud-users.component';
import { CrudBooksComponent } from 'app/component/crud-books/crud-books.component';
import { CrudBookComponent } from 'app/component/crud-book/crud-book.component';

const routes: Routes = [
  {
    path: 'home',
    component: BookListingComponent,
    children: []
  },
  {
    path: 'books',
    component: CrudBooksComponent
  },
  {
    path: 'book',
    component: CrudBookComponent
  },
  {
    path: 'book/:bookId',
    component: CrudBookComponent
  },
  {
    path: 'users',
    component: CrudUsersComponent
  },
  {
    path: 'sign-up',
    component: SignUpComponent
  },
  {
    path: 'sign-in',
    component: SignInComponent
  },
  {
    path: '**',
    redirectTo: 'home'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
