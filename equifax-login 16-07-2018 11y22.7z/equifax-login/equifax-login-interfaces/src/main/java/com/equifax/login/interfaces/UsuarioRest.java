/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 4 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.interfaces;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.equifax.login.bean.TokenUtilBean;
import com.equifax.login.models.Usuario;
import com.equifax.login.utiles.RutaServiciosWeb;

/**
 * @author yxh24
 * @version $Revision: $
 */
@Path(RutaServiciosWeb.RUTA_RAIZ_USUARIO)
public class UsuarioRest {
    @Inject
    private TokenUtilBean tokenBean;

    /**
     * Constructor sin parametros
     */
    public UsuarioRest() {
    }

    /**
     * Valida el usuario y genera un token para los permisos sobre la plataforma
     * @param usuario Entidad Usuario con la informacion para realizar el acceso
     * @return Token de acceso
     */
    @POST
    @Path(RutaServiciosWeb.RUTA_LOGIN_GENERAR_TOKEN_POST)
    @Produces({ MediaType.APPLICATION_JSON + ";charset=utf-8" })
    public Response autenticacionUsuario(Usuario usuario) {
        try {
            /**
             * Codigo de validacion del usuario y password en la BD, si todo es correcto se genera el token
             */
            String token = this.tokenBean.generarTokenDeAcceso(usuario.getName());
            /**
             * Devolvemos el token en la cabecera "Autorizacion"
             */
            return Response.ok().header(HttpHeaders.AUTHORIZATION, RutaServiciosWeb.TOKEN_EQUIFAX + token).build();
        } catch (Exception e) {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
    }
}
