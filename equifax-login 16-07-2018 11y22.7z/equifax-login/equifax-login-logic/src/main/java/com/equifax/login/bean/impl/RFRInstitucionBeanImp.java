/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 26 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean.impl;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.equifax.login.bean.RFRInstitucionBean;
import com.equifax.login.dao.RFRInstitucionDao;
import com.equifax.login.models.RFRInstitucion;
import com.equifax.login.models.RFRInstitucionPK;

/**
 * @author yxh24
 */
@Stateless
public class RFRInstitucionBeanImp implements RFRInstitucionBean {
    @Inject
    private RFRInstitucionDao rfrInstitucionDao;

    /**
     * Crea una nueva instancia de la clase RFRInstitucionBeanImp
     */
    public RFRInstitucionBeanImp() {
    }

    /**
     * Permite Obtener RFRInstitucion por Identificador
     * @param rfrInstitucionPK Identificador PK de RFRInstitucion
     * @return RFRInstitucion
     */
    @Override
    public RFRInstitucion obtenerInstitucionPorIdentificadorPK(RFRInstitucionPK rfrInstitucionPK) {
        return this.rfrInstitucionDao.obtenerInstitucionPorIdentificadorPK(rfrInstitucionPK);
    }

    /**
     * Obtiene todas las intituciones por nombre de su tipo
     * @param rfrInstitucion Entidad con el nombre del RFRInstitucion
     * @return List<RFRInstitucion>
     */
    @Override
    public List<RFRInstitucion> obtenerInstitucionesPorNombreTipo(RFRInstitucion rfrInstitucion) {
        String nombreTipoInstitucion = rfrInstitucion.getNombreTipoInstitucion();
        return this.rfrInstitucionDao.obtenerInstitucionesPorNombreTipo(nombreTipoInstitucion);
    }

    /**
     * Obtiene todas las intituciones por rango de Identificadores
     * @param rfrInstituciones Identificadores de RFRInstitucion
     * @return List<RFRInstitucion>
     */
    @Override
    public List<RFRInstitucion> obtenerInstitucionesPorCodigoInstitucionesPK(List<RFRInstitucion> rfrInstituciones) {
        List<Long> codigos = new ArrayList<Long>();
        for (RFRInstitucion rfrInstitucion : rfrInstituciones) {
            codigos.add(rfrInstitucion.getId().getCodigoInstitucion());
        }
        return this.rfrInstitucionDao.obtenerInstitucionesPorCodigoInstitucionesPK(codigos);
    }
}
