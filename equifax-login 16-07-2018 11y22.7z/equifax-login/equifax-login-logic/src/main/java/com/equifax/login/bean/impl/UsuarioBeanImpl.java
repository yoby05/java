/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 13 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean.impl;

import java.security.Key;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.equifax.login.bean.UsuarioBean;
import com.equifax.login.models.Usuario;

import io.jsonwebtoken.Jwts;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class UsuarioBeanImpl implements UsuarioBean {
    /**
     * Crea una nueva instancia de la clase UsuarioBeanImpl
     */
    public UsuarioBeanImpl() {
    }

    /**
     * Permite obtener un usuario mediante un token
     * @param token Token de seguridad
     * @param key Llave de seguridad
     * @return Usuario Entidad
     */
    @Override
    public Usuario obtenerUsuarioPorToken(String token, Key key) {
        Usuario usuario = new Usuario();
        List<String> roles = new ArrayList<String>();
        usuario.setNombreUsuario(Jwts.parser().setSigningKey(key).parseClaimsJws(token).getBody().getSubject());
        String rolesToken = (String) Jwts.parser().setSigningKey(key).parseClaimsJws(token).getBody().get("roles");
        roles = Arrays.asList(rolesToken.split(","));
        usuario.setRoles(roles);
        return usuario;
    }
}
