/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 2 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

/**
 * Implementacion del patron de acceso a datos con metodos genericos CRUD
 * @author yxh24
 * @version $Revision: $
 * @param <T> Entidad Genérica
 * @param <I>
 */
public class GenericDaoImpl<T, I extends Serializable> {
    @Inject
    protected EntityManager em;
    private final Class<T> tablaEntidad;

    /**
     * Constructor
     * @param tablaEntidad
     */
    public GenericDaoImpl(final Class<T> tablaEntidad) {
        this.tablaEntidad = tablaEntidad;
    }

    /**
     * Metodo generico para insertar un registro
     * @param tablaEntidad tabla de tipo entidad
     */
    public void crear(final T tablaEntidad) {
        this.em.persist(tablaEntidad);
    }

    /**
     * Metodo generico para actualizar un registro
     * @param tablaEntidad tabla de tipo entidad
     * @return tabla de tipo entidad con registro modificado
     */
    public T modificar(final T tablaEntidad) {
        return this.em.merge(tablaEntidad);
    }

    /**
     * Metodo generico para buscar un registro correspondiente a su identificador principal
     * @param identificador
     * @return tabla de tipo entidad
     */
    public T obtenerPorCodigo(Object identificador) {
        return this.em.find(this.tablaEntidad, identificador);
    }

    /**
     * Metodo generico para obtener todos los registros
     * @return lista de registros correspondiente a la tabla de tipo entidad
     */
    public List<T> obtenerTodos() {
        TypedQuery<T> consulta =
                this.em.createQuery("Select t from " + this.tablaEntidad.getSimpleName() + " t", this.tablaEntidad);
        return consulta.getResultList();
    }

    /**
     * Metodo generico para obtener todos los registros paginados
     * @param numeroDePagina numero de la pagina
     * @param elementosPorPagina tamanno o elementos de la pagina
     * @return lista de registros correspondiente a la tabla de tipo entidiad agrupados en paginas
     */
    public List<T> obtenerTodos(int numeroDePagina, int elementosPorPagina) {
        TypedQuery<T> consulta =
                this.em.createQuery("Select t from " + this.tablaEntidad.getSimpleName() + " t", this.tablaEntidad);
        consulta.setFirstResult((numeroDePagina - 1) * elementosPorPagina);
        consulta.setMaxResults(elementosPorPagina);
        return consulta.getResultList();
    }
}
