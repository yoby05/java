/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.utiles;

/**
 * @author yxh24
 * @version $Revision: $
 */
public final class ConstantesUtil {
    /**
     * Constante identifica Si
     */
    public static final String CONDICION_SI = "SI";
    /**
     * Constante identifica No
     */
    public static final String CONDICION_NO = "NO";
    /**
     * Constante identifica Activo
     */
    public static final String CONDICION_ACTIVO = "ACT";
    /**
     * Constante identificar Inactivo
     */
    public static final String CONDICION_INACTIVO = "INA";
    /**
     * Para castear el objeto de una lista
     */
    public static final String UNCHECKED = "unchecked";
    /**
     * Variable para identificar eliminado logico
     */
    public static final String ELIMINADO = "eliminado";
    /**
     * Transformar Fecha
     */
    public static final String STRING_FORMATO_GMT_FECHA_DIA_MES_ANIO = "dd/MM/yyyy";
    /**
     * Codigo del usuario
     */
    public static final String CODIGO_USUARIO = "codigoUsuario";
    /**
     * Codigo de la institucion
     */
    public static final String CODIGO_INSTITUCION = "codigoInstitucion";
    /**
     * Nombre de la Institucion
     */
    public static final String NOMBRE_TIPO_INSTITUCION = "nombreTipoInstitucion";
    /**
     * Rango de codigos
     */
    public static final String CODIGOS = "codigos";
    /**
     * HEADER DE GENERACION DE TOKEN
     */
    public static final String TOKEN_EQUIFAX = "Equifax ";
}
