/*
 * Equifax Ecuador C.A.
 * Sistema: COLLECTOR EC
 * Creado:  25 jul. 2018 
 * 
 * Los contenidos de este archivo son propiedad intelectual de Equifax Ecuador C.A.
 * 
 * Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.utiles;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Define y produce el contexto de persistencia para su obtencion por CDI
 * @author yxh24
 */
public class ContextoPersistenciaUtil {
    /**
     * Contexto de persistencia de conexion a BD Oracle
     */
    @PersistenceContext(unitName = "OracleDS")
    public EntityManager entityManager;

    /**
     * Produce gestor de entidades
     * @param ip punto de inyeccion
     * @return Gestor de Entidades
     */
    @Produces
    public EntityManager getEm(InjectionPoint ip) {
        return this.entityManager;
    }
}
