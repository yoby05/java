/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 4 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean.impl;

import java.io.IOException;
import java.lang.reflect.Method;
import java.security.Key;

import javax.annotation.Priority;
import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.ext.Provider;

import com.equifax.login.bean.UsuarioBean;
import com.equifax.login.contexto.ContextoSeguridad;
import com.equifax.login.models.Usuario;
import com.equifax.login.utiles.ConstantesUtil;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.impl.crypto.MacProvider;

/**
 * @author yxh24
 * @version $Revision: $
 */
@Provider
@Priority(Priorities.AUTHORIZATION)
public class FiltroSEGBeanImpl implements ContainerRequestFilter {
    @Inject
    private UsuarioBean usuarioBean;
    @Context
    private ResourceInfo informacionRecurso;
    /**
     * Contiene la generacion del token
     */
    public static final Key KEY = MacProvider.generateKey();

    @Override
    public void filter(ContainerRequestContext contextoSolicitud) throws IOException {
        /**
         * Pemite manejar la solicitud y extraer las notaciones
         */
        Method metodo = this.informacionRecurso.getResourceMethod();
        /**
         * @DenyAll Denegar todas las solicitudes
         */
        if (metodo.isAnnotationPresent(DenyAll.class)) {
            this.rechazarPeticion(contextoSolicitud);
        }
        /**
         * @RolesAllowed Permitir el acceso a los que se encuentren dentro de la notacion
         */
        RolesAllowed rolesPermitidos = metodo.getAnnotation(RolesAllowed.class);
        if (metodo.getAnnotation(RolesAllowed.class) != null) {
            this.realizarAutorizacion(rolesPermitidos.value(), contextoSolicitud);
            return;
        }
        /**
         * Permite el acceso
         */
        if (metodo.isAnnotationPresent(PermitAll.class)) {
            return;
        }
    }

    /**
     * Permite realizar la autorizacion por roles
     * @param rolesAllowed
     * @param requestContext Contexto Respuesta
     */
    private void realizarAutorizacion(String[] rolesPermitidos, ContainerRequestContext contextoSolicitud) {
        String autorizacionHeader = contextoSolicitud.getHeaderString(HttpHeaders.AUTHORIZATION);
        SecurityContext contextoOriginal = contextoSolicitud.getSecurityContext();
        try {
            /**
             * Extrae el token de la cabecera
             */
            String token = autorizacionHeader.substring(ConstantesUtil.TOKEN_EQUIFAX.length()).trim();
            if (token == null || token.isEmpty()) {
                ContextoSeguridad contextoSEG = new ContextoSeguridad(new Usuario(), contextoOriginal.isSecure());
                contextoSolicitud.setSecurityContext(contextoSEG);
                this.rechazarPeticion(contextoSolicitud);
            } else {
                try {
                    /**
                     * Validar el token
                     */
                    Jwts.parser().setSigningKey(KEY).parseClaimsJws(token);
                    /**
                     * Creamos el usuario a partir de la informacion del token
                     */
                    Usuario usuario = this.usuarioBean.obtenerUsuarioPorToken(token, KEY);
                    /**
                     * Creamos el contexto de seguridad
                     */
                    ContextoSeguridad contextoSEG =
                            new ContextoSeguridad(usuario, contextoSolicitud.getSecurityContext().isSecure());
                    /**
                     * Seteamos el contexto de seguridad
                     */
                    contextoSolicitud.setSecurityContext(contextoSEG);
                    if (this.estaAutenticado(contextoSolicitud)) {
                        for (String rol : rolesPermitidos) {
                            if (contextoSolicitud.getSecurityContext().isUserInRole(rol)) {
                                return;
                            }
                        }
                        this.rechazarPeticion(contextoSolicitud);
                    }
                } catch (Exception ex) {
                    throw new IOException("TOKEN INVALIDO");
                }
            }
        } catch (Exception e) {
            this.rechazarPeticion(contextoSolicitud);
        }
    }

    /**
     * Verifica si el usuario esta auntenticado
     * @param requestContext
     * @return Boolean
     */
    private Boolean estaAutenticado(final ContainerRequestContext contextoSolicitud) {
        return contextoSolicitud.getSecurityContext().getUserPrincipal() != null;
    }

    /**
     * Rechazar peticion
     */
    private void rechazarPeticion(ContainerRequestContext contextoSolicitud) {
        contextoSolicitud.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
    }
}
