/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 9 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean;

/**
 * @author yxh24
 * @version $Revision: $
 */
public interface TokenUtilBean {
    /**
     * Permite generar el token para al acceso a la plataforma
     * @param login Es el nombre de usuario
     * @return Token
     */
    String generarTokenDeAcceso(String login);
}
