/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 13 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean;

import java.security.Key;

import com.equifax.login.models.Usuario;

/**
 * @author yxh24
 * @version $Revision: $
 */
public interface UsuarioBean {
    /**
     * Permite obtener un usuario mediante un token
     * @param token Token de seguridad
     * @param key Llave de seguridad
     * @return Usuario Entidad
     */
    Usuario obtenerUsuarioPorToken(String token, Key key);
}
