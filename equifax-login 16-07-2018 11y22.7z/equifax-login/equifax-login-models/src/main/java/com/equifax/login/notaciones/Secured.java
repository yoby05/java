/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 4 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.notaciones;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.ws.rs.NameBinding;

/**
 * @author yxh24
 * @version $Revision: $
 */
@NameBinding
@Retention(RUNTIME)
@Target({ TYPE, METHOD })
public @interface Secured {
}
