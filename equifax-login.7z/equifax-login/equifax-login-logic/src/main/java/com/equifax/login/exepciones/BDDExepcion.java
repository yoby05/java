/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.exepciones;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class BDDExepcion extends Exception {
    private static final long serialVersionUID = -1609205069680007277L;

    /**
     * Crea una nueva instancia de la clase BDDExepcion
     * @param message
     * @param cause
     */
    public BDDExepcion(final String message, final Throwable cause) {
        super(message, cause);
    }

    /**
     * Crea una nueva instancia de la clase BDDExepcion
     * @param message
     */
    public BDDExepcion(final String message) {
        super(message);
    }
}
