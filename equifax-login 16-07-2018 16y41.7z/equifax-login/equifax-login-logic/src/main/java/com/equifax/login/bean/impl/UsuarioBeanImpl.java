/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 13 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.equifax.login.bean.UsuarioBean;
import com.equifax.login.models.Usuario;
import com.nimbusds.jwt.JWTClaimsSet;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class UsuarioBeanImpl implements UsuarioBean {
    /**
     * Crea una nueva instancia de la clase UsuarioBeanImpl
     */
    public UsuarioBeanImpl() {
    }

    /**
     * Permite obtener un usuario mediante un token
     * @param token Token de seguridad
     * @return Usuario Entidad
     * @throws ParseException
     */
    @Override
    public Usuario obtenerUsuarioPorToken(JWTClaimsSet token) throws ParseException {
        Usuario usuario = new Usuario();
        List<String> roles = new ArrayList<String>();
        usuario.setNombreUsuario(token.getSubject());
        String rolesToken = token.getStringClaim("roles");
        roles = Arrays.asList(rolesToken.split(","));
        usuario.setRoles(roles);
        return usuario;
    }
}
