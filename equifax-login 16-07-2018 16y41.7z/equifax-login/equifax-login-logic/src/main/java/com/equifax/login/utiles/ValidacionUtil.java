/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.utiles;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

/**
 * @author yxh24
 * @version $Revision: $
 */
public final class ValidacionUtil {
    private ValidacionUtil() {
    }

    /**
     * Metodo generico para determinar si un objecto es nulo
     * @param object es el valor de entrada
     * @return Boolean
     */
    public static Boolean esNulo(Object object) {
        return (object == null) ? true : false;
    }

    /**
     * Metodo generico para determinar si un String, Lista, etc esta vacio Se utiliza la expresion unchecked para poder convertir
     * Objeto en List <Object>
     * @param objeto es el valor de entrada
     * @return Boolean
     */
    @SuppressWarnings(ConstantesUtil.UNCHECKED)
    public static Boolean esVacio(Object objeto) {
        if (esNulo(objeto)) {
            return true;
        } else if (objeto instanceof String) {
            if (((String) objeto).trim().equals("")) {
                return true;
            }
        } else if (objeto instanceof String) {
            if (((String) objeto).trim().equals("0")) {
                return true;
            }
        } else if (objeto instanceof List) {
            List<Object> lista = (List<Object>) objeto;
            if (lista.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Valida si el codigo es null o vacio retorna null, caso contrario retorna el numero
     * @param codigo valor de entrada
     * @return Long
     */
    public static Long valLong(Object codigo) {
        return (codigo == null || codigo.toString().trim().isEmpty()) ? null : Long.valueOf(codigo.toString());
    }

    /**
     * Valida si el codigo es null o vacio retorna null, caso contrario retorna el numero
     * @param codigo valor de entrada
     * @return Long
     */
    public static Long valObjeto(Object codigo) {
        return (codigo == null || codigo.toString().equals("0") || codigo.toString().trim().isEmpty()) ? null
                : Long.valueOf(codigo.toString());
    }

    /**
     * Valida si cadena es null o vacio retorna null, caso contrario retorna el cadena
     * @param cadena valor de entrada
     * @return String
     */
    public static String valString(Object cadena) {
        return (cadena == null || cadena.toString().isEmpty()) ? null : cadena.toString();
    }

    /**
     * Valida si fecha es null o invalida retorna null, caso contrario retorna la fecha
     * @param fecha valor de entrada
     * @return Date
     */
    public static Date valDate(Object fecha) {
        if (esNulo(fecha) || "".equals(fecha.toString())) {
            return null;
        }
        Date fechaResultante = null;
        try {
            DateFormat formato = new SimpleDateFormat(ConstantesUtil.STRING_FORMATO_GMT_FECHA_DIA_MES_ANIO);
            fechaResultante = formato.parse(fecha.toString());
        } catch (ParseException e) {
            return null;
        }
        return fechaResultante;
    }

    /**
     * Realiza la conversion del objeto 'valor' al tipo de dato 'Date'.
     * @param valor Objeto para ser convertido a 'Date'.
     * @return Date si el valor es suceptible de conversion, caso contrario nulo.
     * @throws RuntimeException RuntimeException Cuando el objeto 'valor' no es de tipo Date o Calendar.
     */
    public static Date getValorDate(Object valor) {
        Date res = null;
        if (valor == null) {
            res = null;
        } else if (valor instanceof Date) {
            res = (Date) valor;
        } else if (valor instanceof Calendar) {
            res = ((Calendar) valor).getTime();
        } else {
            throw new RuntimeException("El tipo de dato " + valor.getClass().getName()
                    + " no se puede convertir a 'Date', tipos de dato esperado: Date o Calendar");
        }
        return res;
    }

    /**
     * Aumenta un dia a la fecha
     * @param fecha valor de entrada
     * @param dias cantidad de dias
     * @return Date
     */
    public static Date sumarDias(Date fecha, int dias) {
        if (esNulo(fecha)) {
            return null;
        } else {
            Calendar calendario = Calendar.getInstance();
            calendario.setTime(fecha);
            calendario.add(Calendar.DAY_OF_YEAR, dias);
            return calendario.getTime();
        }
    }

    /**
     * Valida si un objeto tiene entrada
     * @param objeto valor de entrada
     * @return Boolean
     */
    public static Boolean contieneInformacion(Object objeto) {
        return (esNulo(objeto) || esVacio(objeto) || objeto.toString().equals("0")) ? false : true;
    }

    /**
     * Realiza la conversion del objeto 'valor' al tipo de dato 'Long'.
     * @param valor Objeto para ser convertido a Long
     * @return Long si el valor es suceptible de conversion, caso contrario nulo.
     * @throws RuntimeException Cuando el objeto 'valor' no es de tipo Long, Integer o BigDecimal.
     */
    public static Long getValorLong(Object valor) {
        Long res = null;
        if (valor == null) {
            res = null;
        } else if (valor instanceof Long) {
            res = (Long) valor;
        } else if (valor instanceof Integer) {
            res = ((Integer) valor).longValue();
        } else if (valor instanceof BigDecimal) {
            res = ((BigDecimal) valor).longValue();
        } else if (valor instanceof String) {
            res = Long.parseLong(valor.toString());
        } else {
            throw new RuntimeException("El tipo de dato " + valor.getClass().getName()
                    + " no se puede convertir a 'Long', tipos de dato esperado: Long, Integer o BigDecimal");
        }
        return res;
    }

    /**
     * Realiza la conversion del objeto 'valor' al tipo de dato 'Integer'.
     * @param valor Objeto para ser convertido a 'Integer'.
     * @return Integer si el valor es suceptible de conversion, caso contrario nulo.
     * @throws RuntimeException RuntimeException Cuando el objeto 'valor' no es de tipo Long, Integer o BigDecimal.
     */
    public static Integer getValorInteger(Object valor) {
        Integer res = null;
        if (valor == null) {
            res = null;
        } else if (valor instanceof Integer) {
            res = (Integer) valor;
        } else if (valor instanceof Long) {
            res = ((Long) valor).intValue();
        } else if (valor instanceof BigDecimal) {
            res = ((BigDecimal) valor).intValue();
        } else if (valor instanceof String) {
            res = Integer.parseInt(valor.toString());
        } else {
            throw new RuntimeException("El tipo de dato " + valor.getClass().getName()
                    + " no se puede convertir a 'Integer', tipos de dato esperado: Long, Integer o BigDecimal");
        }
        return res;
    }

    /**
     * Realiza la conversion del objeto 'valor' al tipo de dato 'BigDecimal'.
     * @param valor Objeto para ser convertido a 'BigDecimal'.
     * @return BigDecimal si el valor es suceptible de conversion, caso contrario nulo.
     * @throws RuntimeException RuntimeException Cuando el objeto 'valor' no es de tipo Long, Integer, Double, Float o BigDecimal.
     */
    public static BigDecimal getValorBigDecimal(Object valor) {
        BigDecimal res = validarBigDecimal(valor);
        return res;
    }

    /**
     * Realiza la conversion del objeto 'valor' al tipo de dato 'BigDecimal'.
     * @param valor Objeto para ser convertido a 'BigDecimal'.
     * @param decimales cantidad de decimales para el redondeo que se aplica
     * @return BigDecimal si el valor es suceptible de conversion, caso contrario nulo.
     * @throws RuntimeException RuntimeException Cuando el objeto 'valor' no es de tipo Long, Integer, Double, Float o BigDecimal.
     */
    public static BigDecimal getValorBigDecimal(Object valor, int decimales) {
        BigDecimal res = validarBigDecimal(valor);
        return res.setScale(decimales, RoundingMode.HALF_UP);
    }

    /**
     * Metodo generico la conversion del objeto 'valor' al tipo de dato 'BigDecimal'.
     * @param valor Objeto para ser convertido a 'BigDecimal'.
     * @return BigDecimal si el valor es suceptible de conversi�nn, caso contrario nulo.
     */
    private static BigDecimal validarBigDecimal(Object valor) {
        BigDecimal res = null;
        if (valor == null) {
            res = null;
        } else if (valor instanceof BigDecimal) {
            res = (BigDecimal) valor;
        } else if (valor instanceof Double) {
            res = BigDecimal.valueOf((Double) valor);
        } else if (valor instanceof Float) {
            res = BigDecimal.valueOf((Float) valor);
        } else if (valor instanceof Long) {
            res = BigDecimal.valueOf((Long) valor);
        } else if (valor instanceof Integer) {
            res = BigDecimal.valueOf((Integer) valor);
        } else {
            throw new RuntimeException("El tipo de dato " + valor.getClass().getName()
                    + " no se puede convertir a 'BigDecimal', tipos de dato esperado: Long, Integer o BigDecimal");
        }
        return res;
    }

    /**
     * Devuelve una lista del tipo que se desee a partir de una lista sin tipo evitando que se genere el warning 'Type safety'.
     * @param listaSinTipo instancia de lista sin tipo
     * @param listaConTipo instancia de lista del tipo que se desee
     * @param tipoDeLista clase cuyo tipo de lista a devolver se espera que sea
     * @return lista del tipo que se desee
     */
    public static <T, C extends List<T>> C transformarAListaConTipo(List<?> listaSinTipo, C listaConTipo, Class<T> tipoDeLista) {
        for (Object item : listaSinTipo) {
            listaConTipo.add(tipoDeLista.cast(item));
        }
        return listaConTipo;
    }

    /**
     * Obtiene lista de cualquier objeto Se utiliza la expresion unchecked para poder convertir a cualquier List <T>
     * @param query Para la consulta
     * @param <T> T generica
     * @return query
     */
    @SuppressWarnings(ConstantesUtil.UNCHECKED)
    public static <T> List<T> convertirLista(Query query) {
        return query.getResultList();
    }
}
