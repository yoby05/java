/*
 * Equifax Ecuador C.A.
 * Sistema: COLLECTOR EC
 * Creado:  26 jul. 2018 
 * 
 * Los contenidos de este archivo son propiedad intelectual de Equifax Ecuador C.A.
 * 
 * Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.enumeradores;

/**
 * @author jrper
 */
public enum EnumMes {
    /**
     * Representa el mes de ENERO
     */
    ENE("ENERO", 1),
    /**
     * Representa el mes de FEBRERO
     */
    FEB("FEBRERO", 2),
    /**
     * Representa el mes de MARZO
     */
    MAR("MARZO", 3),
    /**
     * Representa el mes de ABRIL
     */
    ABR("ABRIL", 4),
    /**
     * Representa el mes de MAYO
     */
    MAY("MAYO", 5),
    /**
     * Representa el mes de JUNIO
     */
    JUN("JUNIO", 6),
    /**
     * Representa el mes de JULIO
     */
    JUL("JULIO", 7),
    /**
     * Representa el mes de AGOSTO
     */
    AGO("AGOSTO", 8),
    /**
     * Representa el mes de SEPTIEMBRE
     */
    SEP("SEPTIEMBRE", 9),
    /**
     * Representa el mes de OCTUBRE
     */
    OCT("OCTUBRE", 10),
    /**
     * Representa el mes de NOVIEMBRE
     */
    NOV("NOVIEMBRE", 11),
    /**
     * Representa el mes de DICIEMBRE
     */
    DIC("DICIEMBRE", 12);
    /**
     * Nombre del mes
     */
    private String descripcion;
    /**
     * Valor numerirco del mes
     */
    private Integer valor;

    /**
     * Crea una nueva instancia de la clase EnumMes
     * @param descripcion descripcion de la enumeracion
     * @param valor valor numerico de la enumeracion
     */
    private EnumMes(String descripcion, Integer valor) {
        this.descripcion = descripcion;
        this.valor = valor;
    }

    /**
     * Obtiene el atributo de clase: "descripcion"
     * @return el/la descripcion
     */
    public String getDescripcion() {
        return this.descripcion;
    }

    /**
     * Asigna valor al atributo de clase: "descripcion"
     * @param descripcion el/la descripcion para asignar el valor
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene el atributo de clase: "valor"
     * @return el/la valor
     */
    public Integer getValor() {
        return this.valor;
    }

    /**
     * Asigna valor al atributo de clase: "valor"
     * @param valor el/la valor para asignar el valor
     */
    public void setValor(Integer valor) {
        this.valor = valor;
    }
}
