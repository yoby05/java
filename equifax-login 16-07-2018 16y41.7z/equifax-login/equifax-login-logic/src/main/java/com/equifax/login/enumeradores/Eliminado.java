/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 25 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.enumeradores;

import java.io.Serializable;

import com.equifax.login.utiles.ConstantesUtil;

/**
 * @author yxh24
 * @version $Revision: $
 */
public enum Eliminado implements Serializable {
    /**
     * Constante identifica Condicion SI
     */
    SI(ConstantesUtil.CONDICION_SI),
    /**
     * Constante identifica Condicion NO
     */
    NO(ConstantesUtil.CONDICION_NO);
    /**
     * Constante identifica descripcion
     */
    public String descripcion;

    /**
     * Constructor de la enumeracion
     * @param descripcion Valor de la descripcion
     */
    private Eliminado(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return descripcion
     */
    public String getDescripcion() {
        return this.descripcion;
    }

    /**
     * @param descripcion Descripcion a modificar
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene el valor
     * @param valor Valor de ingreso
     * @return String
     */
    public static Eliminado fromString(String valor) {
        return valueOf(valor);
    }
}
