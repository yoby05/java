/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 4 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.contexto;

import java.security.Principal;

import javax.ws.rs.core.SecurityContext;

import com.equifax.login.models.Usuario;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class ContextoSeguridad implements SecurityContext {
    private Usuario usuario;
    private boolean esSeguro;

    /**
     * Crea una nueva instancia de la clase ContextoSeguridad
     * @param usuario
     * @param esSeguro
     */
    public ContextoSeguridad(Usuario usuario, boolean esSeguro) {
        this.usuario = usuario;
        this.esSeguro = esSeguro;
    }

    /**
     * Obtiene el atributo de clase: "usuario"
     * @return el/la usuario
     */
    public Usuario getUsuario() {
        return this.usuario;
    }

    /**
     * Asigna valor al atributo de clase: "usuario"
     * @param usuario el/la usuario para asignar el valor
     */
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    /**
     * Obtiene el atributo de clase: "esSeguro"
     * @return el/la esSeguro
     */
    public boolean isEsSeguro() {
        return this.esSeguro;
    }

    /**
     * Asigna valor al atributo de clase: "esSeguro"
     * @param esSeguro el/la esSeguro para asignar el valor
     */
    public void setEsSeguro(boolean esSeguro) {
        this.esSeguro = esSeguro;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getAuthenticationScheme() {
        return SecurityContext.FORM_AUTH;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Principal getUserPrincipal() {
        return this.usuario;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isSecure() {
        return this.esSeguro;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isUserInRole(String rol) {
        if (!this.usuario.getRoles().isEmpty()) {
            return this.usuario.getRoles().contains(rol);
        }
        return false;
    }
}
