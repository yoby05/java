/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 29 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean;

import java.util.List;

import com.equifax.login.models.RFRInstitucion;
import com.equifax.login.models.RFRInstitucionPK;

/**
 * @author yxh24
 */
public interface RFRInstitucionBean {
    /**
     * Permite Obtener RFRInstitucion por Identificador
     * @param rfrInstitucionPK Identificador PK de RFRInstitucion
     * @return RFRInstitucion
     */
    RFRInstitucion obtenerInstitucionPorIdentificadorPK(RFRInstitucionPK rfrInstitucionPK);

    /**
     * Obtiene todas las intituciones por nombre de su tipo
     * @param rfrInstitucion Entidad con el nombre del RFRInstitucion
     * @return List<RFRInstitucion>
     */
    List<RFRInstitucion> obtenerInstitucionesPorNombreTipo(RFRInstitucion rfrInstitucion);

    /**
     * Obtiene todas las intituciones por rango de Identificadores
     * @param rfrInstituciones Identificadores de RFRInstitucion
     * @return List<RFRInstitucion>
     */
    List<RFRInstitucion> obtenerInstitucionesPorCodigoInstitucionesPK(List<RFRInstitucion> rfrInstituciones);
}
