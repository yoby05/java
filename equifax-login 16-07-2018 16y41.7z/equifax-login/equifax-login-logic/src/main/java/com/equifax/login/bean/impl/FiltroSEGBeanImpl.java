/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 4 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean.impl;

import java.io.IOException;
import java.lang.reflect.Method;
import java.security.Key;
import java.text.ParseException;
import java.util.Date;

import javax.annotation.Priority;
import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.ext.Provider;

import com.equifax.login.bean.TokenUtilBean;
import com.equifax.login.bean.UsuarioBean;
import com.equifax.login.contexto.ContextoSeguridad;
import com.equifax.login.models.Usuario;
import com.equifax.login.utiles.ConstantesUtil;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jwt.JWTClaimsSet;

import io.jsonwebtoken.impl.crypto.MacProvider;

/**
 * @author yxh24
 * @version $Revision: $
 */
@Provider
@Priority(Priorities.AUTHORIZATION)
public class FiltroSEGBeanImpl implements ContainerRequestFilter {
    @Inject
    private TokenUtilBean tokenUtilBean;
    @Inject
    private UsuarioBean usuarioBean;
    @Context
    private ResourceInfo informacionRecurso;
    /**
     * Contiene la generacion del token
     */
    public static final Key KEY = MacProvider.generateKey();

    @Override
    public void filter(ContainerRequestContext contextoSolicitud) throws IOException {
        /**
         * Pemite manejar la solicitud y extraer las notaciones
         */
        Method metodo = informacionRecurso.getResourceMethod();
        /**
         * @DenyAll Denegar todas las solicitudes
         */
        if (metodo.isAnnotationPresent(DenyAll.class)) {
            rechazarPeticion(contextoSolicitud);
        }
        /**
         * @RolesAllowed Permitir el acceso a los que se encuentren dentro de la notacion
         */
        RolesAllowed rolesPermitidos = metodo.getAnnotation(RolesAllowed.class);
        if (metodo.getAnnotation(RolesAllowed.class) != null) {
            realizarAutorizacion(rolesPermitidos.value(), contextoSolicitud);
            return;
        }
        /**
         * Permite el acceso
         */
        if (metodo.isAnnotationPresent(PermitAll.class)) {
            return;
        }
    }

    /**
     * Permite realizar la autorizacion por roles
     * @param rolesAllowed roles permitos para realizar la peticion
     * @param requestContext Contexto Respuesta
     */
    private void realizarAutorizacion(String[] rolesPermitidos, ContainerRequestContext contextoSolicitud) {
        String autorizacionHeader = contextoSolicitud.getHeaderString(HttpHeaders.AUTHORIZATION);
        SecurityContext contextoOriginal = contextoSolicitud.getSecurityContext();
        try {
            if (autorizacionHeader == null || autorizacionHeader.isEmpty() || autorizacionHeader.split(" ").length != 2) {
                ContextoSeguridad contextoSEG = new ContextoSeguridad(new Usuario(), contextoOriginal.isSecure());
                contextoSolicitud.setSecurityContext(contextoSEG);
                rechazarPeticion(contextoSolicitud);
            } else {
                JWTClaimsSet claimsSet;
                try {
                    /**
                     * Validar el token
                     */
                    claimsSet = tokenUtilBean.desencriptorToken(autorizacionHeader);
                } catch (ParseException ex) {
                    throw new IOException(ConstantesUtil.ERROR_JWT_DECODIFICAR);
                } catch (JOSEException ex) {
                    throw new IOException(ConstantesUtil.ERROR_TOKEN_INVALIDO);
                }
                if (claimsSet.getExpirationTime().before(new Date())) {
                    throw new IOException(ConstantesUtil.ERROR_TOKEN_EXPIRADO);
                } else {
                    /**
                     * Creamos el usuario a partir de la informacion del token
                     */
                    Usuario usuario = usuarioBean.obtenerUsuarioPorToken(claimsSet);
                    /**
                     * Creamos el contexto de seguridad
                     */
                    ContextoSeguridad contextoSEG =
                            new ContextoSeguridad(usuario, contextoSolicitud.getSecurityContext().isSecure());
                    /**
                     * Seteamos el contexto de seguridad
                     */
                    contextoSolicitud.setSecurityContext(contextoSEG);
                    if (estaAutenticado(contextoSolicitud)) {
                        for (String rol : rolesPermitidos) {
                            if (contextoSolicitud.getSecurityContext().isUserInRole(rol)) {
                                return;
                            }
                        }
                        rechazarPeticion(contextoSolicitud);
                    }
                }
            }
        } catch (Exception e) {
            rechazarPeticion(contextoSolicitud);
        }
    }

    /**
     * Verifica si el usuario esta auntenticado
     * @param requestContext
     * @return Boolean
     */
    private Boolean estaAutenticado(final ContainerRequestContext contextoSolicitud) {
        return contextoSolicitud.getSecurityContext().getUserPrincipal() != null;
    }

    /**
     * Rechazar peticion
     */
    private void rechazarPeticion(ContainerRequestContext contextoSolicitud) {
        contextoSolicitud.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
    }
}
