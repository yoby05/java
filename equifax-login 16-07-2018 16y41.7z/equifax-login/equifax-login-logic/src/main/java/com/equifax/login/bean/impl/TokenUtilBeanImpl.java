/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 9 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bean.impl;

import java.text.ParseException;
import java.util.Date;

import com.equifax.login.bean.TokenUtilBean;
import com.equifax.login.utiles.ConstantesUtil;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class TokenUtilBeanImpl implements TokenUtilBean {
    /*
     * Llave debe de recuperarse desde la base
     */
    private static String LLAVE_PRIVADA =
            "uqkL@D)GmNe=+K$H<#E7GtkQVJtkd3^:!G!L{??Tb(Nkz8(@,m2\\]W{9SZN,ctzH+J+az\\c_}T\"w+@dhNn^3m*('`6wJ4MXr7R[tE3?eH#h+X\"@:/=^LzHUD2S3c^#H3NmM\"[^p]my]TTXu/F/.d)A^Kq`@T:<W/Me5.(]!G''djR$XyRUg)7EE^bNP,d>_A@fq{Fp]n:\"T$Dg3z*[bp@S)sM,Q%K5{7H@#%^h-6Pj25~aryS5;c5q%~+Dp3R)zt";
    private static JWSHeader JWT_HEADER = new JWSHeader(JWSAlgorithm.HS256);

    /**
     * Constructor sin parametros
     */
    public TokenUtilBeanImpl() {
    }

    /**
     * Permite generar el token para al acceso a la plataforma
     * @param login Es el nombre de usuario
     * @return Token nuevo
     * @throws JOSEException
     */
    @Override
    public String generarTokenDeAcceso(String login) throws JOSEException {
        /**
         * Realizar login de la base con usuario y contrase�a y obtener sus roles
         */
        JWTClaimsSet.Builder claimsSet = new JWTClaimsSet.Builder();
        claimsSet.issuer("https://efxcentral.eis.equifax.com");
        claimsSet.subject(login);
        claimsSet.claim("roles", "ADMIN,OPERACIONES");
        claimsSet.expirationTime(new Date(new Date().getTime() + 1000 * 60 * 30));
        claimsSet.notBeforeTime(new Date());
        JWSSigner jwsSigner = new MACSigner(LLAVE_PRIVADA);
        SignedJWT jwt = new SignedJWT(JWT_HEADER, claimsSet.build());
        jwt.sign(jwsSigner);
        return jwt.serialize();
    }

    /**
     * Realiza la desencriptacion del token
     * @param token desencriptado
     * @return JWTClaimsSet
     * @throws ParseException
     * @throws JOSEException
     */
    @Override
    public JWTClaimsSet desencriptorToken(String token) throws ParseException, JOSEException {
        SignedJWT jwt = SignedJWT.parse(obtenerTokenSerializado(token));
        if (jwt.verify(new MACVerifier(LLAVE_PRIVADA))) {
            return jwt.getJWTClaimsSet();
        } else {
            throw new JOSEException(ConstantesUtil.ERROR_TOKEN_FIRMA);
        }
    }

    /**
     * Obtiene el codigo del token
     * @param token
     * @return token Serializado
     */
    @Override
    public String obtenerTokenSerializado(String token) {
        return token.split(" ")[1];
    }
}
