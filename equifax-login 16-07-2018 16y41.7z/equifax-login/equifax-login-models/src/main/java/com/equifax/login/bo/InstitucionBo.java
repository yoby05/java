/*
 * Equifax Ecuador C.A. Sistema: COLLECTOR EC Creado: 3 jul. 2018 Los contenidos de este archivo son propiedad intelectual de
 * Equifax Ecuador C.A. Copyright 2008-2018 Equifax Ecuador C.A. Todos los derechos reservados.
 */
package com.equifax.login.bo;

import java.io.Serializable;

/**
 * @author yxh24
 * @version $Revision: $
 */
public class InstitucionBo implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long codigoRFRInstitucion;
    private Long codigoEstadoDocumento;
    private String nombreInstitucion;
    private Long codigoTipoInstitucion;
    private String nombreTipoInstitucion;

    /**
     * Constructor sin parametros
     */
    public InstitucionBo() {
    }

    /**
     * Obtiene el atributo de clase: "codigoRFRInstitucion"
     * @return el/la codigoRFRInstitucion
     */
    public Long getCodigoRFRInstitucion() {
        return this.codigoRFRInstitucion;
    }

    /**
     * Asigna valor al atributo de clase: "codigoRFRInstitucion"
     * @param codigoRFRInstitucion el/la codigoRFRInstitucion para asignar el valor
     */
    public void setCodigoRFRInstitucion(Long codigoRFRInstitucion) {
        this.codigoRFRInstitucion = codigoRFRInstitucion;
    }

    /**
     * Obtiene el atributo de clase: "codigoEstadoDocumento"
     * @return el/la codigoEstadoDocumento
     */
    public Long getCodigoEstadoDocumento() {
        return this.codigoEstadoDocumento;
    }

    /**
     * Asigna valor al atributo de clase: "codigoEstadoDocumento"
     * @param codigoEstadoDocumento el/la codigoEstadoDocumento para asignar el valor
     */
    public void setCodigoEstadoDocumento(Long codigoEstadoDocumento) {
        this.codigoEstadoDocumento = codigoEstadoDocumento;
    }

    /**
     * Obtiene el atributo de clase: "nombreInstitucion"
     * @return el/la nombreInstitucion
     */
    public String getNombreInstitucion() {
        return this.nombreInstitucion;
    }

    /**
     * Asigna valor al atributo de clase: "nombreInstitucion"
     * @param nombreInstitucion el/la nombreInstitucion para asignar el valor
     */
    public void setNombreInstitucion(String nombreInstitucion) {
        this.nombreInstitucion = nombreInstitucion;
    }

    /**
     * Obtiene el atributo de clase: "codigoTipoInstitucion"
     * @return el/la codigoTipoInstitucion
     */
    public Long getCodigoTipoInstitucion() {
        return this.codigoTipoInstitucion;
    }

    /**
     * Asigna valor al atributo de clase: "codigoTipoInstitucion"
     * @param codigoTipoInstitucion el/la codigoTipoInstitucion para asignar el valor
     */
    public void setCodigoTipoInstitucion(Long codigoTipoInstitucion) {
        this.codigoTipoInstitucion = codigoTipoInstitucion;
    }

    /**
     * Obtiene el atributo de clase: "nombreTipoInstitucion"
     * @return el/la nombreTipoInstitucion
     */
    public String getNombreTipoInstitucion() {
        return this.nombreTipoInstitucion;
    }

    /**
     * Asigna valor al atributo de clase: "nombreTipoInstitucion"
     * @param nombreTipoInstitucion el/la nombreTipoInstitucion para asignar el valor
     */
    public void setNombreTipoInstitucion(String nombreTipoInstitucion) {
        this.nombreTipoInstitucion = nombreTipoInstitucion;
    }
}
