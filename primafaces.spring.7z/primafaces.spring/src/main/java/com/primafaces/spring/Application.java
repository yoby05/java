package com.primafaces.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.openfeign.EnableFeignClients;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import com.ulisesbocchio.jasyptspringboot.annotation.EncryptablePropertySource;

/**
 * @author yxh24
 * @version $Revision: $
 */
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
@EnableCaching
@EnableFeignClients
@EnableCircuitBreaker
@EnableEncryptableProperties
@EncryptablePropertySource(name = "application", value = "application.properties")
public class Application extends SpringBootServletInitializer {
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(Application.class);
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
    /*
     * // *PARA JBOSS
     * @Override public void onStartup(ServletContext container) throws ServletException { WebApplicationContext context =
     * this.getContext(); ServletRegistration.Dynamic registration = container.addServlet("dispatcher", new
     * DispatcherServlet(context)); registration.setLoadOnStartup(1); registration.addMapping("/efx-app-tablero-gestion/*");
     * super.onStartup(container); } private WebApplicationContext getContext() { AnnotationConfigWebApplicationContext context =
     * new AnnotationConfigWebApplicationContext(); context.setConfigLocation(Application.class.getName()); return context; }
     */
}
